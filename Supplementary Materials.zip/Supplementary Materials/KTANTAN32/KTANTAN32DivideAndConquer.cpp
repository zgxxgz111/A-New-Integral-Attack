# include "gurobi_c++.h"
# include <time.h>
# include <bitset>
# include <iostream>  
# include <vector>   
# include <map>    
# include <fstream>   
# include <exception>
# include<string>
# include<sstream>

using namespace std;

int IR[254] = { 1,1,1,1,1,1,1,0,0,0,1,1,0,1,0,1,0,1,0,1,1,1,1,0,1,1,0,0,1,1,0,0,1,0,1,0,0,1,0,0,0,1,0,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,0,
				0,0,0,1,0,1,0,0,0,0,0,1,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,0,0,1,0,1,0,1,0,0,1,1,0,0,0,0,1,1,0,0,1,1,1,0,1,1,1,1,1,0,1,1,
				1,0,1,0,0,1,0,1,0,1,1,0,1,0,0,1,1,1,0,0,1,1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,0,1,1,1,0,0,1,0,
				0,1,0,0,1,1,0,1,0,0,0,1,1,1,0,0,0,1,0,0,1,1,1,1,0,1,0,0,0,0,1,1,1,0,1,0,1,1,0,0,0,0,0,1,0,1,1,0,0,1,0,0,0,0,0,0,1,1,0,1,
				1,1,0,0,0,0,0,0,0,1,0,0,1,0 };

//Initial division property and end division property 
int EndDivisionProperty[1][112] =
{
  {0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
};
int Cube[32] = { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0 }; //Used to set the initial division property

struct cmpBitsetN   
{                   
	bool operator()(const bitset<112>& a, const bitset<112>& b) const  
	{
		for (int i = 0; i < 112; i++)
		{
			if (a[i] < b[i])
				return true;
			else if (a[i] > b[i])
				return false;
		}
		return false;
	}
};

struct twoStage {
	bool useTwoStage;
	int divRound;
	vector<bitset<112>> hint;   // Used to store intermediate state
};

int ModelConstructFunction(int EvalNumRounds, map<bitset<112>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d);

//IR=0
void OneRoundConstraints0(GRBModel& model, vector<GRBVar>& x, int j)
{
	GRBVar l1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l5 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar k1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k8 = model.addVar(0, 1, 0, GRB_BINARY);

	//	L1
	model.addConstr(x[4] <= l1 + l2);
	model.addConstr(l1 <= x[4]);
	model.addConstr(l2 <= x[4]);
	model.addConstr(x[5] <= l3 + l4);
	model.addConstr(l3 <= x[5]);
	model.addConstr(l4 <= x[5]);
	model.addConstr(x[7] <= l1 + l5);
	model.addConstr(l1 <= x[7]);
	model.addConstr(l5 <= x[7]);

	//L2
	model.addConstr(x[19] <= k1 + k2);
	model.addConstr(k1 <= x[19]);
	model.addConstr(k2 <= x[19]);
	model.addConstr(x[21] <= k1 + k3);
	model.addConstr(k1 <= x[21]);
	model.addConstr(k3 <= x[21]);
	model.addConstr(x[23] <= k4 + k5);
	model.addConstr(k4 <= x[23]);
	model.addConstr(k5 <= x[23]);
	model.addConstr(x[24] <= k6 + k7);
	model.addConstr(k6 <= x[24]);
	model.addConstr(k7 <= x[24]);
	model.addConstr(x[28] <= k4 + k8);
	model.addConstr(k4 <= x[28]);
	model.addConstr(k8 <= x[28]);

	x[4] = l2;
	x[5] = l4;
	x[7] = l5;

	x[19] = k2;
	x[21] = k3;
	x[23] = k5;
	x[24] = k7;
	x[28] = k8;

	//Read key
	string line;
	ifstream ifs("key.txt");

	for (int count = 0; count < j; count++) {
		getline(ifs, line);
	}


	if (getline(ifs, line)) {
		string div1 = ",";
		string div2 = " ";
		string data1, data2, data3, data4;
		stringstream ss1,ss2,ss3;
		int a, b, c;
		int iPosEnd = line.find(div1);
		data1 = line.substr(0, iPosEnd);
		data2 = line.substr(iPosEnd + 1);

		iPosEnd = data2.find(div2);
		if (iPosEnd == -1) {
			ss1 << data1;
			ss1 >> a;
			ss2 << data2;
			ss2 >> b;
			//copy
			GRBVar m1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m4 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[32 + 79 - a] <= m1 + m2);
			model.addConstr(m1 <= x[32 + 79 - a]);
			model.addConstr(m2 <= x[32 + 79 - a]);
			x[32 + 79 - a] = m1;

			model.addConstr(x[32 + 79 - b] <= m3 + m4);
			model.addConstr(m3 <= x[32 + 79 - b]);
			model.addConstr(m4 <= x[32 + 79 - b]);
			x[32 + 79 - b] = m3;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY); 
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[13] + k6 + k1 + k4 + m4);
			model.addConstr(tmp2 == x[0] + l3 + l1 + m2);
			x[13] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(32);
			for (int i = 0; i < 32; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 32; i++){
				x[i] = tmp3[(i + 1) % 32];
			}

		}
		else {
			data3 = data2.substr(0, iPosEnd);
			data4 = data2.substr(iPosEnd + 1);
			ss1 << data1;
			ss1 >> a;
			ss2 << data3;
			ss2 >> b;
			ss3 << data4;
			ss3 >> c;
			//3 bits copy
			GRBVar m1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m4 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m5 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m6 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[32 + 79 - a] <= m1 + m2);
			model.addConstr(m1 <= x[32 + 79 - a]);
			model.addConstr(m2 <= x[32 + 79 - a]);
			x[32 + 79 - a] = m1;

			model.addConstr(x[32 + 79 - b] <= m3 + m4);
			model.addConstr(m3 <= x[32 + 79 - b]);
			model.addConstr(m4 <= x[32 + 79 - b]);
			x[32 + 79 - b] = m3;

			model.addConstr(x[32 + 79 - c] <= m5 + m6);
			model.addConstr(m5 <= x[32 + 79 - c]);
			model.addConstr(m6 <= x[32 + 79 - c]);
			x[32 + 79 - c] = m5;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[13] + k6 + k1 + k4 + m4 + m6);
			model.addConstr(tmp2 == x[0] + l3 + l1 + m2);
			x[13] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(32);
			for (int i = 0; i < 32; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 32; i++) {
				x[i] = tmp3[(i + 1) % 32];
			}
		}

	}


}

//IR=1
void OneRoundConstraints1(GRBModel& model, vector<GRBVar>& x, int j)
{
	GRBVar l1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l7 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar k1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k8 = model.addVar(0, 1, 0, GRB_BINARY);

	//L1
	model.addConstr(x[4] <= l1 + l2);
	model.addConstr(l1 <= x[4]);
	model.addConstr(l2 <= x[4]);
	model.addConstr(x[5] <= l3 + l4);
	model.addConstr(l3 <= x[5]);
	model.addConstr(l4 <= x[5]);
	model.addConstr(x[7] <= l1 + l5);
	model.addConstr(l1 <= x[7]);
	model.addConstr(l5 <= x[7]);
	model.addConstr(x[9] <= l6 + l7);
	model.addConstr(l6 <= x[9]);
	model.addConstr(l7 <= x[9]);

	//L2
	model.addConstr(x[19] <= k1 + k2);
	model.addConstr(k1 <= x[19]);
	model.addConstr(k2 <= x[19]);
	model.addConstr(x[21] <= k1 + k3);
	model.addConstr(k1 <= x[21]);
	model.addConstr(k3 <= x[21]);
	model.addConstr(x[23] <= k4 + k5);
	model.addConstr(k4 <= x[23]);
	model.addConstr(k5 <= x[23]);
	model.addConstr(x[24] <= k6 + k7);
	model.addConstr(k6 <= x[24]);
	model.addConstr(k7 <= x[24]);
	model.addConstr(x[28] <= k4 + k8);
	model.addConstr(k4 <= x[28]);
	model.addConstr(k8 <= x[28]);

	x[4] = l2;
	x[5] = l4;
	x[7] = l5;
	x[9] = l7;

	x[19] = k2;
	x[21] = k3;
	x[23] = k5;
	x[24] = k7;
	x[28] = k8;

	//key
	string line;
	ifstream ifs("key.txt");

	for (int count = 0; count < j; count++) {
		getline(ifs, line);
	}


	if (getline(ifs, line)) {
		string div1 = ",";
		string div2 = " ";
		string data1, data2, data3, data4;
		stringstream ss1, ss2, ss3;
		int a, b, c;
		int iPosEnd = line.find(div1);
		data1 = line.substr(0, iPosEnd);//
		data2 = line.substr(iPosEnd + 1);//

		iPosEnd = data2.find(div2);
		if (iPosEnd == -1) {
			ss1 << data1;
			ss1 >> a;
			ss2 << data2;
			ss2 >> b;
			//2 bits copy
			GRBVar m1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m4 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[32 + 79 - a] <= m1 + m2);
			model.addConstr(m1 <= x[32 + 79 - a]);
			model.addConstr(m2 <= x[32 + 79 - a]);
			x[32 + 79 - a] = m1;

			model.addConstr(x[32 + 79 - b] <= m3 + m4);
			model.addConstr(m3 <= x[32 + 79 - b]);
			model.addConstr(m4 <= x[32 + 79 - b]);
			x[32 + 79 - b] = m3;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[13] + k6 + k1 + k4 + m4);
			model.addConstr(tmp2 == x[0] + l3 + l1 + l6 + m2);
			x[13] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(32);
			for (int i = 0; i < 32; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 32; i++) {
				x[i] = tmp3[(i + 1) % 32];
			}

		}
		else {
			data3 = data2.substr(0, iPosEnd);
			data4 = data2.substr(iPosEnd + 1);
			ss1 << data1;
			ss1 >> a;
			ss2 << data3;
			ss2 >> b;
			ss3 << data4;
			ss3 >> c;
			//3 bits copy
			GRBVar m1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m4 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m5 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m6 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[32 + 79 - a] <= m1 + m2);
			model.addConstr(m1 <= x[32 + 79 - a]);
			model.addConstr(m2 <= x[32 + 79 - a]);
			x[32 + 79 - a] = m1;

			model.addConstr(x[32 + 79 - b] <= m3 + m4);
			model.addConstr(m3 <= x[32 + 79 - b]);
			model.addConstr(m4 <= x[32 + 79 - b]);
			x[32 + 79 - b] = m3;

			model.addConstr(x[32 + 79 - c] <= m5 + m6);
			model.addConstr(m5 <= x[32 + 79 - c]);
			model.addConstr(m6 <= x[32 + 79 - c]);
			x[32 + 79 - c] = m5;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[13] + k6 + k1 + k4 + m4 + m6);
			model.addConstr(tmp2 == x[0] + l3 + l1+ l6 + m2);
			x[13] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(32);
			for (int i = 0; i < 32; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 32; i++) {
				x[i] = tmp3[(i + 1) % 32];
			}
		}

	}

}

//callback
class MyCallBack : public GRBCallback
{
public:
	vector<vector<GRBVar>> N_S;
	map<bitset<112>, int, cmpBitsetN>* N_CountingBox;
	int N_ThreadNumber;
	ofstream* N_OutputFile;
	int N_d;

	MyCallBack(vector<vector<GRBVar>> s, map<bitset<112>, int, cmpBitsetN>* CountingBox, int ThreadNumber, ofstream* OutputFile, int d) {
		N_S = s;
		N_CountingBox = CountingBox;
		N_ThreadNumber = ThreadNumber;
		N_OutputFile = OutputFile;
		N_d = d;
	};
protected:
	void callback() {
		try {
			if (where == GRB_CB_MIPSOL) {
				int EvalNumRounds = N_S.size() - 1;
				int divRound = EvalNumRounds / 2;
				*N_OutputFile << "divided in " << divRound << "\t" << getDoubleInfo(GRB_CB_RUNTIME) << "sec" << endl;


				//store found solution into trail
				vector<bitset<112>> trail(EvalNumRounds + 1);
				for (int r = 0; r <= EvalNumRounds; r++) {
					for (int i = 0; i < 112; i++) {
						if (round(getSolution(N_S[r][i])) == 1) trail[r][i] = 1;
						else trail[r][i] = 0;
					}
				}
				double duration = 0;
				int solCnt = ModelConstructFunction(EvalNumRounds, *N_CountingBox, duration, N_ThreadNumber, { true, divRound, trail }, N_d);


				int solTotal = 0;
				auto it = (*N_CountingBox).begin();
				while (it != (*N_CountingBox).end()) {
					solTotal += (*it).second;
					it++;
				}

				(*N_OutputFile) << "\t" << solCnt << "( total : " << solTotal << ")" << endl;
				(*N_OutputFile) << "\t" << (*N_CountingBox).size() << " monomials are involved" << endl;

				GRBLinExpr addCon = 0;
				for (int i = 0; i < 112; i++) {
					if (round(getSolution(N_S[divRound][i])) == 1) {
						addCon += (1 - N_S[divRound][i]);
					}
					else {
						addCon += N_S[divRound][i];
					}
				}
				addLazy(addCon >= 1);
			}
			else if (where == GRB_CB_MESSAGE) {
				string msg = getStringInfo(GRB_CB_MSG_STRING);
				*N_OutputFile << msg << flush;
			}

		}
		catch (GRBException e) {
			cerr << "Error number: " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}
		catch (...) {
			cout << "Error during callback" << endl;
		}
	}
};

int ModelConstructFunction(int EvalNumRounds, map<bitset<112>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d) {
	try {
		// Create the environment
		GRBEnv env = GRBEnv();

		// close standard output
		env.set(GRB_IntParam_LogToConsole, 0);
		env.set(GRB_IntParam_Threads, ThreadNumber);
		env.set(GRB_IntParam_MIPFocus, GRB_MIPFOCUS_BESTBOUND);

		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			env.set(GRB_IntParam_LazyConstraints, 1);
			env.set(GRB_DoubleParam_TimeLimit, 50000);// T=50000s
		}
		else if ((opt.useTwoStage == true) && (opt.hint.size() > 0)) {
			env.set(GRB_IntParam_PoolSearchMode, 2);
			env.set(GRB_IntParam_PoolSolutions, 2000000000);
			env.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);
		}

		// Create the model
		GRBModel model = GRBModel(env);

		// Create variables
		vector<vector<GRBVar>> s(EvalNumRounds + 1, vector<GRBVar>(112));
		for (int i = 0; i < 112; i++) {
			s[0][i] = model.addVar(0, 1, 0, GRB_BINARY);
		}

		//Set the initial division property
		for (int i = 0; i < 32; i++) {
			if (Cube[i] == 1) {
				model.addConstr(s[0][i] == 1);
			}
			else {
				model.addConstr(s[0][i] == 0);
			}
		}


		for (int r = 0; r < EvalNumRounds; r++) {
			vector<GRBVar> temp = s[r];

			if (IR[r] == 0) {
				OneRoundConstraints0(model, temp, r);
			}
			else if (IR[r] == 1) {
				OneRoundConstraints1(model, temp, r);
			}

			for (int i = 0; i < 112; i++) {
				s[r + 1][i] = temp[i];
			}

		}

		//Set the end division property 
		for (int i = 0; i < 112; i++) {
			if ((EndDivisionProperty[d][i] == 1))
				model.addConstr(s[EvalNumRounds][i] == 1);
			else
				model.addConstr(s[EvalNumRounds][i] == 0);
		}

		GRBLinExpr sumKey = 0;
		for (int i = 32; i < 112; i++) {
			sumKey += s[0][i];
		}
		model.setObjective(sumKey, GRB_MAXIMIZE);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {

				for (int i = 0; i < 112; i++) {
					if (opt.hint[opt.divRound][i] == 1)
						model.addConstr(s[opt.divRound][i] == 1);
					else
						model.addConstr(s[opt.divRound][i] == 0);
				}

				for (int r = 0; r < EvalNumRounds; r++) {
					for (int i = 0; i < 112; i++) {
						if (opt.hint[r][i] == 1)
							s[r][i].set(GRB_DoubleAttr_Start, 1);
						else
							s[r][i].set(GRB_DoubleAttr_Start, 0);
					}
				}
			}
		}

		ofstream outputfile2;
		outputfile2.open("StartDivisionPropertyInformation(101,0).txt", ios::app);//status == 2

		model.update();
		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			MyCallBack MCB = MyCallBack(s, &countingBox, ThreadNumber, &outputfile2, d);
			model.setCallback(&MCB);
			model.optimize();
		}
		else {
			model.optimize();
		}

		// The number of total solutions and the time to obtain the total solutions
		int SolCount = model.get(GRB_IntAttr_SolCount);
		duration = model.get(GRB_DoubleAttr_Runtime);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {
				// check solution limit
				if (SolCount >= 2000000000) {
					cerr << "Number of solutions is too large" << endl;
					exit(0);
				}

				// store the information about solutions
				for (int i = 0; i < SolCount; i++) {
					model.set(GRB_IntParam_SolutionNumber, i);
					bitset<112> tmp;
					for (int j = 0; j < 112; j++) {
						if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
						else tmp[j] = 0;
					}
					countingBox[tmp]++;
				}

				return SolCount;
			}
		}
		else {
			// check solution limit
			if (SolCount >= 2000000000) {
				cerr << "Number of solutions is too large" << endl;
				exit(0);
			}

			// store the information about solutions
			for (int i = 0; i < SolCount; i++) {
				model.set(GRB_IntParam_SolutionNumber, i);
				bitset<112> tmp;
				for (int j = 0; j < 112; j++) {
					if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
					else tmp[j] = 0;
				}
				countingBox[tmp]++;
			}
		}

		//result
		if (model.get(GRB_IntAttr_Status) == GRB_INFEASIBLE) {
			return -1;
		}
		else if ((model.get(GRB_IntAttr_Status) == GRB_OPTIMAL)) {
			int upperBound = round(model.get(GRB_DoubleAttr_ObjVal));
			return upperBound;
		}
		else {
			cout << model.get(GRB_IntAttr_Status) << endl;
			return -2;
		}

	}
	catch (GRBException e) {
		cerr << "Error code = " << e.getErrorCode() << endl;
		cerr << e.getMessage() << endl;
	}
	catch (...) {
		cerr << "Exception during optimization" << endl;
	}

	return -1;
}


int main()
{
	double duration = 0;
	int ThreadNumber = 8, EvalNumRounds = 0;  
	int StartRounds = 0, EndRounds = 0;
	cout << " the number of Starting rounds:" << endl;
	cin >> StartRounds;
	cout << " the number of Ending rounds:" << endl;
	cin >> EndRounds;
	EvalNumRounds = EndRounds - StartRounds;
	map<bitset<112>, int, cmpBitsetN> countingBox;

	ofstream outputfile1;
	outputfile1.open("Timelimit(101,0).txt", ios::out);//status == 9
	outputfile1.close();

	ofstream outputfile2;
	outputfile2.open("StartDivisionPropertyInformation(101,0).txt", ios::out);//status == 2
	outputfile2.close();

	ofstream outputfile3;
	outputfile3.open("EndDivisionPropertyInformation(101,0).txt", ios::out);
	outputfile3.close();

	for (int d = 0; d < 1; d++) {   // 63639
		try {

			//countingBox
			ModelConstructFunction(EvalNumRounds, countingBox, duration, ThreadNumber, { true,0, }, d);

			ofstream outputfile2;
			outputfile2.open("StartDivisionPropertyInformation(101,0).txt", ios::app);  //status == 2
			auto it = countingBox.begin();
			while (it != countingBox.end()) {
				if (((*it).second % 2) == 1) {
					outputfile2 << "Parity of occurrence times��" << (*it).second % 2 << " " << " The actual number of occurrences��" << (*it).second << "\t";
					for (int i = 32; i < 112; i++) {
						if ((*it).first[i] == 1) {
							outputfile2 << "k" << (i - 32); // 
						}
					}
					outputfile2 << endl;
				}
				it++;
			}
			outputfile2 << "Total time��" << duration << "sec";
			outputfile2.close();
		}
		catch (GRBException e) {
			cerr << "Error code = " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}

		catch (...) {
			cerr << "Exception during optimization" << endl;
		}

	}
}
