# include "gurobi_c++.h"
# include <time.h>
# include <bitset>
# include <iostream>  
# include <vector>   
# include <map>    
# include <fstream>   // 
# include <exception>
# include<string>
# include<sstream>

using namespace std;

int IR[254] = { 1,1,1,1,1,1,1,0,0,0,1,1,0,1,0,1,0,1,0,1,1,1,1,0,1,1,0,0,1,1,0,0,1,0,1,0,0,1,0,0,0,1,0,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,0,
				0,0,0,1,0,1,0,0,0,0,0,1,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,0,0,1,0,1,0,1,0,0,1,1,0,0,0,0,1,1,0,0,1,1,1,0,1,1,1,1,1,0,1,1,
				1,0,1,0,0,1,0,1,0,1,1,0,1,0,0,1,1,1,0,0,1,1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,0,1,1,1,0,0,1,0,
				0,1,0,0,1,1,0,1,0,0,0,1,1,1,0,0,0,1,0,0,1,1,1,1,0,1,0,0,0,0,1,1,1,0,1,0,1,1,0,0,0,0,0,1,0,1,1,0,0,1,0,0,0,0,0,0,1,1,0,1,
				1,1,0,0,0,0,0,0,0,1,0,0,1,0 };

//Initial division property and end division property 
int EndDivisionProperty[1][128] =
{
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
};
int Cube[48] = { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0 }; //Used to set the initial division property


struct cmpBitsetN   
{                   
	bool operator()(const bitset<128>& a, const bitset<128>& b) const  
	{
		for (int i = 0; i < 128; i++)
		{
			if (a[i] < b[i])
				return true;
			else if (a[i] > b[i])
				return false;
		}
		return false;
	}
};

struct twoStage {
	bool useTwoStage;
	int divRound;
	vector<bitset<128>> hint;    // Used to store intermediate state
};

int ModelConstructFunction(int EvalNumRounds, map<bitset<128>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d);

//IR=0
void OneRoundConstraints0(GRBModel& model, vector<GRBVar>& x, int j)
{
	GRBVar l1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l5 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar k1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k8 = model.addVar(0, 1, 0, GRB_BINARY);

	//L1
	model.addConstr(x[3] <= l1 + l2);
	model.addConstr(l1 <= x[3]);
	model.addConstr(l2 <= x[3]);
	model.addConstr(x[6] <= l3 + l4);
	model.addConstr(l3 <= x[6]);
	model.addConstr(l4 <= x[6]);
	model.addConstr(x[11] <= l1 + l5);
	model.addConstr(l1 <= x[11]);
	model.addConstr(l5 <= x[11]);

	//L2
	model.addConstr(x[26] <= k1 + k2);
	model.addConstr(k1 <= x[26]);
	model.addConstr(k2 <= x[26]);
	model.addConstr(x[28] <= k3 + k4);
	model.addConstr(k3 <= x[28]);
	model.addConstr(k4 <= x[28]);
	model.addConstr(x[32] <= k5 + k6);
	model.addConstr(k5 <= x[32]);
	model.addConstr(k6 <= x[32]);
	model.addConstr(x[34] <= k1 + k7);
	model.addConstr(k1 <= x[34]);
	model.addConstr(k7 <= x[34]);
	model.addConstr(x[41] <= k5 + k8);
	model.addConstr(k5 <= x[41]);
	model.addConstr(k8 <= x[41]);

	x[3] = l2;
	x[6] = l4;
	x[11] = l5;

	x[26] = k2;
	x[28] = k4;
	x[32] = k6;
	x[34] = k7;
	x[41] = k8;

	//key
	string line1;
	ifstream ifs("key.txt");

	for (int count = 0; count < j; count++) {
		getline(ifs, line1);
	}

	//cout << line1 << endl;

	if (getline(ifs, line1)) {
		string div1 = ",";
		string div2 = " ";
		string data1, data2, data3, data4;
		stringstream ss1, ss2, ss3;
		int a, b, c;
		int iPosEnd = line1.find(div1);
		data1 = line1.substr(0, iPosEnd);//
		data2 = line1.substr(iPosEnd + 1);//

		iPosEnd = data2.find(div2);
		if (iPosEnd == -1) {
			ss1 << data1;
			ss1 >> a;
			ss2 << data2;
			ss2 >> b;
			//2 bits copy
			GRBVar m1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m4 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[48 + 79 - a] <= m1 + m2);
			model.addConstr(m1 <= x[48 + 79 - a]);
			model.addConstr(m2 <= x[48 + 79 - a]);
			x[48 + 79 - a] = m1;

			model.addConstr(x[48 + 79 - b] <= m3 + m4);
			model.addConstr(m3 <= x[48 + 79 - b]);
			model.addConstr(m4 <= x[48 + 79 - b]);
			x[48 + 79 - b] = m3;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[19] + k3 + k1 + k5 + m4);
			model.addConstr(tmp2 == x[0] + l3 + l1 + m2);
			x[19] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(48);
			for (int i = 0; i < 48; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 48; i++) {
				x[i] = tmp3[(i + 1) % 48];
			}
		}
		else {
			data3 = data2.substr(0, iPosEnd);
			data4 = data2.substr(iPosEnd + 1);
			ss1 << data1;
			ss1 >> a;
			ss2 << data3;
			ss2 >> b;
			ss3 << data4;
			ss3 >> c;
			//3 bits copy
			GRBVar m1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m4 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m5 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m6 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[48 + 79 - a] <= m1 + m2);
			model.addConstr(m1 <= x[48 + 79 - a]);
			model.addConstr(m2 <= x[48 + 79 - a]);
			x[48 + 79 - a] = m1;

			model.addConstr(x[48 + 79 - b] <= m3 + m4);
			model.addConstr(m3 <= x[48 + 79 - b]);
			model.addConstr(m4 <= x[48 + 79 - b]);
			x[48 + 79 - b] = m3;

			model.addConstr(x[48 + 79 - c] <= m5 + m6);
			model.addConstr(m5 <= x[48 + 79 - c]);
			model.addConstr(m6 <= x[48 + 79 - c]);
			x[48 + 79 - c] = m5;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[19] + k3 + k1 + k5 + m4 + m6);
			model.addConstr(tmp2 == x[0] + l3 + l1 + m2);
			x[19] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(48);
			for (int i = 0; i < 48; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 48; i++) {
				x[i] = tmp3[(i + 1) % 48];
			}
		}
	}
	ifs.close();






	GRBVar p1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p5 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar q1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q8 = model.addVar(0, 1, 0, GRB_BINARY);

	//L1
	model.addConstr(x[3] <= p1 + p2);
	model.addConstr(p1 <= x[3]);
	model.addConstr(p2 <= x[3]);
	model.addConstr(x[6] <= p3 + p4);
	model.addConstr(p3 <= x[6]);
	model.addConstr(p4 <= x[6]);
	model.addConstr(x[11] <= p1 + p5);
	model.addConstr(p1 <= x[11]);
	model.addConstr(p5 <= x[11]);

	//L2
	model.addConstr(x[26] <= q1 + q2);
	model.addConstr(q1 <= x[26]);
	model.addConstr(q2 <= x[26]);
	model.addConstr(x[28] <= q3 + q4);
	model.addConstr(q3 <= x[28]);
	model.addConstr(q4 <= x[28]);
	model.addConstr(x[32] <= q5 + q6);
	model.addConstr(q5 <= x[32]);
	model.addConstr(q6 <= x[32]);
	model.addConstr(x[34] <= q1 + q7);
	model.addConstr(q1 <= x[34]);
	model.addConstr(q7 <= x[34]);
	model.addConstr(x[41] <= q5 + q8);
	model.addConstr(q5 <= x[41]);
	model.addConstr(q8 <= x[41]);

	x[3] = p2;
	x[6] = p4;
	x[11] = p5;

	x[26] = q2;
	x[28] = q4;
	x[32] = q6;
	x[34] = q7;
	x[41] = q8;

	//key
	string line2;
	ifstream ifst("key.txt");

	for (int count = 0; count < j; count++) {
		getline(ifst, line2);
	}

	if (getline(ifst, line2)) {
		string div1 = ",";
		string div2 = " ";
		string data1, data2, data3, data4;
		stringstream ss1, ss2, ss3;
		int a, b, c;
		int iPosEnd = line2.find(div1);
		data1 = line2.substr(0, iPosEnd);//
		data2 = line2.substr(iPosEnd + 1);//

		iPosEnd = data2.find(div2);
		if (iPosEnd == -1) {
			ss1 << data1;
			ss1 >> a;
			ss2 << data2;
			ss2 >> b;
			//2 bits
			GRBVar n1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n4 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[48 + 79 - a] <= n1 + n2);
			model.addConstr(n1 <= x[48 + 79 - a]);
			model.addConstr(n2 <= x[48 + 79 - a]);
			x[48 + 79 - a] = n1;

			model.addConstr(x[48 + 79 - b] <= n3 + n4);
			model.addConstr(n3 <= x[48 + 79 - b]);
			model.addConstr(n4 <= x[48 + 79 - b]);
			x[48 + 79 - b] = n3;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[19] + q3 + q1 + q5 + n4);
			model.addConstr(tmp2 == x[0] + p3 + p1 + n2);
			x[19] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(48);
			for (int i = 0; i < 48; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 48; i++) {
				x[i] = tmp3[(i + 1) % 48];
			}
		}
		else {
			data3 = data2.substr(0, iPosEnd);
			data4 = data2.substr(iPosEnd + 1);
			ss1 << data1;
			ss1 >> a;
			ss2 << data3;
			ss2 >> b;
			ss3 << data4;
			ss3 >> c;
			//3 bits copy
			GRBVar n1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n4 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n5 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n6 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[48 + 79 - a] <= n1 + n2);
			model.addConstr(n1 <= x[48 + 79 - a]);
			model.addConstr(n2 <= x[48 + 79 - a]);
			x[48 + 79 - a] = n1;

			model.addConstr(x[48 + 79 - b] <= n3 + n4);
			model.addConstr(n3 <= x[48 + 79 - b]);
			model.addConstr(n4 <= x[48 + 79 - b]);
			x[48 + 79 - b] = n3;

			model.addConstr(x[48 + 79 - c] <= n5 + n6);
			model.addConstr(n5 <= x[48 + 79 - c]);
			model.addConstr(n6 <= x[48 + 79 - c]);
			x[48 + 79 - c] = n5;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[19] + q3 + q1 + q5 + n4 + n6);
			model.addConstr(tmp2 == x[0] + p3 + p1 + n2);
			x[19] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(48);
			for (int i = 0; i < 48; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 48; i++) {
				x[i] = tmp3[(i + 1) % 48];
			}
		}

	}
	ifst.close();
}

//IR=1
void OneRoundConstraints1(GRBModel& model, vector<GRBVar>& x, int j)
{
	GRBVar l1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar l7 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar k1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar k8 = model.addVar(0, 1, 0, GRB_BINARY);

	//L1
	model.addConstr(x[3] <= l1 + l2);
	model.addConstr(l1 <= x[3]);
	model.addConstr(l2 <= x[3]);
	model.addConstr(x[6] <= l3 + l4);
	model.addConstr(l3 <= x[6]);
	model.addConstr(l4 <= x[6]);
	model.addConstr(x[11] <= l1 + l5);
	model.addConstr(l1 <= x[11]);
	model.addConstr(l5 <= x[11]);
	model.addConstr(x[12] <= l6 + l7);
	model.addConstr(l6 <= x[12]);
	model.addConstr(l7 <= x[12]);

	//L2
	model.addConstr(x[26] <= k1 + k2);
	model.addConstr(k1 <= x[26]);
	model.addConstr(k2 <= x[26]);
	model.addConstr(x[28] <= k3 + k4);
	model.addConstr(k3 <= x[28]);
	model.addConstr(k4 <= x[28]);
	model.addConstr(x[32] <= k5 + k6);
	model.addConstr(k5 <= x[32]);
	model.addConstr(k6 <= x[32]);
	model.addConstr(x[34] <= k1 + k7);
	model.addConstr(k1 <= x[34]);
	model.addConstr(k7 <= x[34]);
	model.addConstr(x[41] <= k5 + k8);
	model.addConstr(k5 <= x[41]);
	model.addConstr(k8 <= x[41]);

	x[3] = l2;
	x[6] = l4;
	x[11] = l5;
	x[12] = l7;

	x[26] = k2;
	x[28] = k4;
	x[32] = k6;
	x[34] = k7;
	x[41] = k8;

	//key
	string line1;
	ifstream ifs("key.txt");

	for (int count = 0; count < j; count++) {
		getline(ifs, line1);
	}

	if (getline(ifs, line1)) {
		string div1 = ",";
		string div2 = " ";
		string data1, data2, data3, data4;
		stringstream ss1, ss2, ss3;
		int a, b, c;
		int iPosEnd = line1.find(div1);
		data1 = line1.substr(0, iPosEnd);
		data2 = line1.substr(iPosEnd + 1);

		iPosEnd = data2.find(div2);
		if (iPosEnd == -1) {
			ss1 << data1;
			ss1 >> a;
			ss2 << data2;
			ss2 >> b;
			//2 bits copy
			GRBVar m1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m4 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[48 + 79 - a] <= m1 + m2);
			model.addConstr(m1 <= x[48 + 79 - a]);
			model.addConstr(m2 <= x[48 + 79 - a]);
			x[48 + 79 - a] = m1;

			model.addConstr(x[48 + 79 - b] <= m3 + m4);
			model.addConstr(m3 <= x[48 + 79 - b]);
			model.addConstr(m4 <= x[48 + 79 - b]);
			x[48 + 79 - b] = m3;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[19] + k3 + k1 + k5 + m4);
			model.addConstr(tmp2 == x[0] + l3 + l1 + l6 + m2);
			x[19] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(48);
			for (int i = 0; i < 48; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 48; i++) {
				x[i] = tmp3[(i + 1) % 48];
			}
		}
		else {
			data3 = data2.substr(0, iPosEnd);
			data4 = data2.substr(iPosEnd + 1);
			ss1 << data1;
			ss1 >> a;
			ss2 << data3;
			ss2 >> b;
			ss3 << data4;
			ss3 >> c;
			//3 bits copy
			GRBVar m1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m4 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m5 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar m6 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[48 + 79 - a] <= m1 + m2);
			model.addConstr(m1 <= x[48 + 79 - a]);
			model.addConstr(m2 <= x[48 + 79 - a]);
			x[48 + 79 - a] = m1;

			model.addConstr(x[48 + 79 - b] <= m3 + m4);
			model.addConstr(m3 <= x[48 + 79 - b]);
			model.addConstr(m4 <= x[48 + 79 - b]);
			x[48 + 79 - b] = m3;

			model.addConstr(x[48 + 79 - c] <= m5 + m6);
			model.addConstr(m5 <= x[48 + 79 - c]);
			model.addConstr(m6 <= x[48 + 79 - c]);
			x[48 + 79 - c] = m5;

			GRBVar tmp1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp2 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp1 == x[19] + k3 + k1 + k5 + m4 + m6);
			model.addConstr(tmp2 == x[0] + l3 + l1 + l6 + m2);
			x[19] = tmp1;
			x[0] = tmp2;

			vector<GRBVar> tmp3(48);
			for (int i = 0; i < 48; i++) {
				tmp3[i] = x[i];
			}
			for (int i = 0; i < 48; i++) {
				x[i] = tmp3[(i + 1) % 48];
			}
		}
	}
	ifs.close();






	GRBVar p1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p7 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar q1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar q8 = model.addVar(0, 1, 0, GRB_BINARY);

	//L1
	model.addConstr(x[3] <= p1 + p2);
	model.addConstr(p1 <= x[3]);
	model.addConstr(p2 <= x[3]);
	model.addConstr(x[6] <= p3 + p4);
	model.addConstr(p3 <= x[6]);
	model.addConstr(p4 <= x[6]);
	model.addConstr(x[11] <= p1 + p5);
	model.addConstr(p1 <= x[11]);
	model.addConstr(p5 <= x[11]);
	model.addConstr(x[12] <= p6 + p7);
	model.addConstr(p6 <= x[12]);
	model.addConstr(p7 <= x[12]);

	//L2
	model.addConstr(x[26] <= q1 + q2);
	model.addConstr(q1 <= x[26]);
	model.addConstr(q2 <= x[26]);
	model.addConstr(x[28] <= q3 + q4);
	model.addConstr(q3 <= x[28]);
	model.addConstr(q4 <= x[28]);
	model.addConstr(x[32] <= q5 + q6);
	model.addConstr(q5 <= x[32]);
	model.addConstr(q6 <= x[32]);
	model.addConstr(x[34] <= q1 + q7);
	model.addConstr(q1 <= x[34]);
	model.addConstr(q7 <= x[34]);
	model.addConstr(x[41] <= q5 + q8);
	model.addConstr(q5 <= x[41]);
	model.addConstr(q8 <= x[41]);

	x[3] = p2;
	x[6] = p4;
	x[11] = p5;
	x[12] = p7;

	x[26] = q2;
	x[28] = q4;
	x[32] = q6;
	x[34] = q7;
	x[41] = q8;

	//key
	string line2;
	ifstream ifst("key.txt");

	for (int count = 0; count < j; count++) {
		getline(ifst, line2);
	}

	if (getline(ifst, line2)) {
		string div1 = ",";
		string div2 = " ";
		string data5, data6, data7, data8;
		stringstream ss4, ss5, ss6;
		int a, b, c;
		int iPosEnd2 = line2.find(div1);
		data5 = line2.substr(0, iPosEnd2);
		data6 = line2.substr(iPosEnd2 + 1);

		iPosEnd2 = data6.find(div2);
		if (iPosEnd2 == -1) {
			ss4 << data5;
			ss4 >> a;
			ss5 << data6;
			ss5 >> b;
			//2 bits copy
			GRBVar n1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n4 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[48 + 79 - a] <= n1 + n2);
			model.addConstr(n1 <= x[48 + 79 - a]);
			model.addConstr(n2 <= x[48 + 79 - a]);
			x[48 + 79 - a] = n1;

			model.addConstr(x[48 + 79 - b] <= n3 + n4);
			model.addConstr(n3 <= x[48 + 79 - b]);
			model.addConstr(n4 <= x[48 + 79 - b]);
			x[48 + 79 - b] = n3;

			GRBVar tmp3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp4 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp3 == x[19] + q3 + q1 + q5 + n4);
			model.addConstr(tmp4 == x[0] + p3 + p1 + p6 + n2);
			x[19] = tmp3;
			x[0] = tmp4;

			vector<GRBVar> tmp5(48);
			for (int i = 0; i < 48; i++) {
				tmp5[i] = x[i];
			}
			for (int i = 0; i < 48; i++) {
				x[i] = tmp5[(i + 1) % 48];
			}
		}
		else {
			data7 = data6.substr(0, iPosEnd2);
			data8 = data6.substr(iPosEnd2 + 1);
			ss4 << data5;
			ss4 >> a;
			ss5 << data7;
			ss5 >> b;
			ss6 << data8;
			ss6 >> c;
			//3 bits copy
			GRBVar n1 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n2 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n4 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n5 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar n6 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(x[48 + 79 - a] <= n1 + n2);
			model.addConstr(n1 <= x[48 + 79 - a]);
			model.addConstr(n2 <= x[48 + 79 - a]);
			x[48 + 79 - a] = n1;

			model.addConstr(x[48 + 79 - b] <= n3 + n4);
			model.addConstr(n3 <= x[48 + 79 - b]);
			model.addConstr(n4 <= x[48 + 79 - b]);
			x[48 + 79 - b] = n3;

			model.addConstr(x[48 + 79 - c] <= n5 + n6);
			model.addConstr(n5 <= x[48 + 79 - c]);
			model.addConstr(n6 <= x[48 + 79 - c]);
			x[48 + 79 - c] = n5;

			GRBVar tmp3 = model.addVar(0, 1, 0, GRB_BINARY);
			GRBVar tmp4 = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(tmp3 == x[19] + q3 + q1 + q5 + n4 + n6);
			model.addConstr(tmp4 == x[0] + p3 + p1 + p6 + n2);
			x[19] = tmp3;
			x[0] = tmp4;

			vector<GRBVar> tmp5(48);
			for (int i = 0; i < 48; i++) {
				tmp5[i] = x[i];
			}
			for (int i = 0; i < 48; i++) {
				x[i] = tmp5[(i + 1) % 48];
			}
		}

	}
	ifst.close();
}

//callback
class MyCallBack : public GRBCallback
{
public:
	vector<vector<GRBVar>> N_S;
	map<bitset<128>, int, cmpBitsetN>* N_CountingBox;
	int N_ThreadNumber;
	ofstream* N_OutputFile;
	int N_d;

	MyCallBack(vector<vector<GRBVar>> s, map<bitset<128>, int, cmpBitsetN>* CountingBox, int ThreadNumber, ofstream* OutputFile, int d) {
		N_S = s;
		N_CountingBox = CountingBox;
		N_ThreadNumber = ThreadNumber;
		N_OutputFile = OutputFile;
		N_d = d;
	};
protected:
	void callback() {
		try {
			if (where == GRB_CB_MIPSOL) {
				int EvalNumRounds = N_S.size() - 1;
				int divRound = EvalNumRounds / 2;
				*N_OutputFile << "divided in " << divRound << "\t" << getDoubleInfo(GRB_CB_RUNTIME) << "sec" << endl;


				//store found solution into trail
				vector<bitset<128>> trail(EvalNumRounds + 1);
				for (int r = 0; r <= EvalNumRounds; r++) {
					for (int i = 0; i < 128; i++) {
						if (round(getSolution(N_S[r][i])) == 1) trail[r][i] = 1;
						else trail[r][i] = 0;
					}
				}
				double duration = 0;
				int solCnt = ModelConstructFunction(EvalNumRounds, *N_CountingBox, duration, N_ThreadNumber, { true, divRound, trail }, N_d);


				int solTotal = 0;
				auto it = (*N_CountingBox).begin();
				while (it != (*N_CountingBox).end()) {
					solTotal += (*it).second;
					it++;
				}

				(*N_OutputFile) << "\t" << solCnt << "( total : " << solTotal << ")" << endl;
				(*N_OutputFile) << "\t" << (*N_CountingBox).size() << " monomials are involved" << endl;

				GRBLinExpr addCon = 0;
				for (int i = 0; i < 128; i++) {
					if (round(getSolution(N_S[divRound][i])) == 1) {
						addCon += (1 - N_S[divRound][i]);
					}
					else {
						addCon += N_S[divRound][i];
					}
				}
				addLazy(addCon >= 1);
			}
			else if (where == GRB_CB_MESSAGE) {
				string msg = getStringInfo(GRB_CB_MSG_STRING);
				*N_OutputFile << msg << flush;
			}

		}
		catch (GRBException e) {
			cerr << "Error number: " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}
		catch (...) {
			cout << "Error during callback" << endl;
		}
	}
};

int ModelConstructFunction(int EvalNumRounds, map<bitset<128>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d) {
	try {
		// Create the environment
		GRBEnv env = GRBEnv();

		// close standard output
		env.set(GRB_IntParam_LogToConsole, 0);
		env.set(GRB_IntParam_Threads, ThreadNumber);
		env.set(GRB_IntParam_MIPFocus, GRB_MIPFOCUS_BESTBOUND);

		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			env.set(GRB_IntParam_LazyConstraints, 1);
			env.set(GRB_DoubleParam_TimeLimit, 500000);
		}
		else if ((opt.useTwoStage == true) && (opt.hint.size() > 0)) {
			env.set(GRB_IntParam_PoolSearchMode, 2);
			env.set(GRB_IntParam_PoolSolutions, 2000000000);
			env.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);
		}

		// Create the model
		GRBModel model = GRBModel(env);

		// Create variables
		vector<vector<GRBVar>> s(EvalNumRounds + 1, vector<GRBVar>(128));
		for (int i = 0; i < 128; i++) {
			s[0][i] = model.addVar(0, 1, 0, GRB_BINARY);
		}

		//Set the initial division property
		for (int i = 0; i < 48; i++) {
			if (Cube[i] == 1) {
				model.addConstr(s[0][i] == 1);
			}
			else {
				model.addConstr(s[0][i] == 0);
			}
		}


		for (int r = 0; r < EvalNumRounds; r++) {
			vector<GRBVar> temp = s[r];

			if (IR[r] == 0) {
				OneRoundConstraints0(model, temp, r);
			}
			else if (IR[r] == 1) {
				OneRoundConstraints1(model, temp, r);
			}

			for (int i = 0; i < 128; i++) {
				s[r + 1][i] = temp[i];
			}

		}

		//Set the end division property 
		for (int i = 0; i < 128; i++) {
			if ((EndDivisionProperty[d][i] == 1))
				model.addConstr(s[EvalNumRounds][i] == 1);
			else
				model.addConstr(s[EvalNumRounds][i] == 0);
		}


		GRBLinExpr sumKey = 0;
		for (int i = 48; i < 128; i++) {
			sumKey += s[0][i];
		}
		model.setObjective(sumKey, GRB_MAXIMIZE);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {

				for (int i = 0; i < 128; i++) {
					if (opt.hint[opt.divRound][i] == 1)
						model.addConstr(s[opt.divRound][i] == 1);
					else
						model.addConstr(s[opt.divRound][i] == 0);
				}

				for (int r = 0; r < EvalNumRounds; r++) {
					for (int i = 0; i < 128; i++) {
						if (opt.hint[r][i] == 1)
							s[r][i].set(GRB_DoubleAttr_Start, 1);
						else
							s[r][i].set(GRB_DoubleAttr_Start, 0);
					}
				}
			}
		}

		ofstream outputfile2;
		outputfile2.open("StartDivisionPropertyInformation(85,0).txt", ios::app);//status == 2

		model.update();
		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			MyCallBack MCB = MyCallBack(s, &countingBox, ThreadNumber, &outputfile2, d);
			model.setCallback(&MCB);
			model.optimize();
		}
		else {
			model.optimize();
		}

		// The number of total solutions and the time to obtain the total solutions
		int SolCount = model.get(GRB_IntAttr_SolCount);
		duration = model.get(GRB_DoubleAttr_Runtime);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {
				// check solution limit
				if (SolCount >= 2000000000) {
					cerr << "Number of solutions is too large" << endl;
					exit(0);
				}

				// store the information about solutions
				for (int i = 0; i < SolCount; i++) {
					model.set(GRB_IntParam_SolutionNumber, i);
					bitset<128> tmp;
					for (int j = 0; j < 128; j++) {
						if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
						else tmp[j] = 0;
					}
					countingBox[tmp]++;
				}

				return SolCount;
			}
		}
		else {
			// check solution limit
			if (SolCount >= 2000000000) {
				cerr << "Number of solutions is too large" << endl;
				exit(0);
			}

			// store the information about solutions
			for (int i = 0; i < SolCount; i++) {
				model.set(GRB_IntParam_SolutionNumber, i);
				bitset<128> tmp;
				for (int j = 0; j < 128; j++) {
					if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
					else tmp[j] = 0;
				}
				countingBox[tmp]++;
			}
		}

		//result
		if (model.get(GRB_IntAttr_Status) == GRB_INFEASIBLE) {
			return -1;
		}
		else if ((model.get(GRB_IntAttr_Status) == GRB_OPTIMAL)) {
			int upperBound = round(model.get(GRB_DoubleAttr_ObjVal));
			return upperBound;
		}
		else {
			cout << model.get(GRB_IntAttr_Status) << endl;
			return -2;
		}

	}
	catch (GRBException e) {
		cerr << "Error code = " << e.getErrorCode() << endl;
		cerr << e.getMessage() << endl;
	}
	catch (...) {
		cerr << "Exception during optimization" << endl;
	}

	return -1;
}


int main()
{
	double duration = 0;
	int ThreadNumber = 8, EvalNumRounds = 0;  
	int StartRounds = 0, EndRounds = 0;
	cout << "the number of Starting rounds:" << endl;
	cin >> StartRounds;
	cout << " the number of Ending rounds:" << endl;
	cin >> EndRounds;
	EvalNumRounds = EndRounds - StartRounds;
	map<bitset<128>, int, cmpBitsetN> countingBox;

	ofstream outputfile1;
	outputfile1.open("Timelimit(85,0).txt", ios::out);//status == 9
	outputfile1.close();

	ofstream outputfile2;
	outputfile2.open("StartDivisionPropertyInformation(85,0).txt", ios::out);//status == 2
	outputfile2.close();

	ofstream outputfile3;
	outputfile3.open("EndDivisionPropertyInformation(85,0).txt", ios::out);
	outputfile3.close();


	for (int d = 0; d < 1; d++) {   // 63639
		try {

			//countingBox
			ModelConstructFunction(EvalNumRounds, countingBox, duration, ThreadNumber, { true,0, }, d);


			ofstream outputfile2;
			outputfile2.open("StartDivisionPropertyInformation(85,0).txt", ios::app);  //status == 2
			auto it = countingBox.begin();
			while (it != countingBox.end()) {
				if (((*it).second % 2) == 1) {
					outputfile2 << "Parity of occurrence times��" << (*it).second % 2 << " " << "The actual number of occurrences��" << (*it).second << "\t";
					for (int i = 48; i < 128; i++) {
						if ((*it).first[i] == 1) {
							outputfile2 << "k" << (i - 48); //k0��k1��������k63
						}
					}
					outputfile2 << endl;
				}
				it++;
			}
			outputfile2 << "Total time��" << duration << "sec";
			outputfile2.close();
		}
		catch (GRBException e) {
			cerr << "Error code = " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}

		catch (...) {
			cerr << "Exception during optimization" << endl;
		}

	}
}
