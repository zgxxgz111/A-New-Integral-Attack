This folder contains the integral polynomial of KTANTAN48.
Let's illustrate the meaning of each file's name.
For example, 'StartDivisionPropertyInformation(85R,0)' represents 
the integral polynomial of 85-round KTANTAN48. We can get the integral polynomial p 
 corresponding to  the initial division property in47 by summing up all the monomials in the file.
'key.txt' represents how to use the subkey bits in every round. 