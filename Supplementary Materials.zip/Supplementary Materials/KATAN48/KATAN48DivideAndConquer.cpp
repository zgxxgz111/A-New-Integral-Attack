# include "gurobi_c++.h"
# include <time.h>
# include <bitset>
# include <iostream>  
# include <vector>   
# include <map>    
# include <fstream>  
# include <exception>

using namespace std;
int IR[254] = { 1,1,1,1,1,1,1,0,0,0,1,1,0,1,0,1,0,1,0,1,1,1,1,0,1,1,0,0,1,1,0,0,1,0,1,0,0,1,0,0,0,1,0,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,0,
				0,0,0,1,0,1,0,0,0,0,0,1,1,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,0,0,1,0,1,0,1,0,0,1,1,0,0,0,0,1,1,0,0,1,1,1,0,1,1,1,1,1,0,1,1,
				1,0,1,0,0,1,0,1,0,1,1,0,1,0,0,1,1,1,0,0,1,1,0,1,1,0,0,0,1,0,1,1,1,0,1,1,0,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,0,1,1,1,0,0,1,0,
				0,1,0,0,1,1,0,1,0,0,0,1,1,1,0,0,0,1,0,0,1,1,1,1,0,1,0,0,0,0,1,1,1,0,1,0,1,1,0,0,0,0,0,1,0,1,1,0,0,1,0,0,0,0,0,0,1,1,0,1,
				1,1,0,0,0,0,0,0,0,1,0,0,1,0 };

//Initial division property and end division property 
int EndDivisionProperty[1][128] =
{
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
};
int Cube[48] = { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,  1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,  1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0 }; //Used to set the initial division property

struct cmpBitsetN   
{                   
	bool operator()(const bitset<128>& a, const bitset<128>& b) const  
	{
		for (int i = 0; i < 128; i++)
		{
			if (a[i] < b[i])
				return true;
			else if (a[i] > b[i])
				return false;
		}
		return false;
	}
};

struct twoStage {
	bool useTwoStage;
	int divRound;
	vector<bitset<128>> hint;   // Used to store intermediate state
};

int ModelConstructFunction(int EvalNumRounds, map<bitset<128>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d);

void OneRoundKeyScheduleConstraint(GRBModel& model, vector<GRBVar>& m)
{
	GRBVar n1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar n2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar n3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar n4 = model.addVar(0, 1, 0, GRB_BINARY);
	//GRBVar x111 = model.addVar(0, 1, 0, GRB_BINARY

	GRBVar p1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar p3 = model.addVar(0, 1, 0, GRB_BINARY);

	model.addConstr(m[60] <= n1 + p1);
	model.addConstr(n1 <= m[60]);
	model.addConstr(p1 <= m[60]);

	model.addConstr(m[97] <= n2 + p2);
	model.addConstr(n2 <= m[97]);
	model.addConstr(p2 <= m[97]);

	model.addConstr(m[108] <= n3 + p3);
	model.addConstr(n3 <= m[108]);
	model.addConstr(p3 <= m[108]);

	model.addConstr(n4 == m[127] + p1 + p2 + p3);

	m[60] = n1;
	m[97] = n2;
	m[108] = n3;
	m[127] = n4;
}

//IR=0
void OneRoundConstraints00(GRBModel& model, vector<GRBVar>& x)
{
	GRBVar y1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y10 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y11 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar a = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar b = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar c = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar z1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z8 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z9 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z10 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z11 = model.addVar(0, 1, 0, GRB_BINARY);

	model.addConstr(x[6] <= y1 + z1);
	model.addConstr(y1 <= x[6]);
	model.addConstr(z1 <= x[6]);

	model.addConstr(x[3] <= a + z2);
	model.addConstr(a <= x[3]);
	model.addConstr(z2 <= x[3]);

	model.addConstr(x[11] <= a + z3);
	model.addConstr(a <= x[11]);
	model.addConstr(z3 <= x[11]);

	model.addConstr(x[127] <= y4 + z4);
	model.addConstr(y4 <= x[127]);
	model.addConstr(z4 <= x[127]);

	model.addConstr(x[28] <= y5 + z5);
	model.addConstr(y5 <= x[28]);
	model.addConstr(z5 <= x[28]);

	model.addConstr(x[26] <= b + z6);
	model.addConstr(b <= x[26]);
	model.addConstr(z6 <= x[26]);

	model.addConstr(x[34] <= b + z7);
	model.addConstr(b <= x[34]);
	model.addConstr(z7 <= x[34]);

	model.addConstr(x[32] <= c + z8);
	model.addConstr(c <= x[32]);
	model.addConstr(z8 <= x[32]);

	model.addConstr(x[41] <= c + z9);
	model.addConstr(c <= x[41]);
	model.addConstr(z9 <= x[41]);

	model.addConstr(x[126] <= y10 + z10);
	model.addConstr(y10 <= x[126]);
	model.addConstr(z10 <= x[126]);

	model.addConstr(y11 == x[0] + y1 + a + y4);
	model.addConstr(z11 == x[19] + y5 + b + c + y10);

	x[6] = z1;
	x[3] = z2;
	x[11] = z3;
	x[127] = z4;
	x[0] = y11;

	x[28] = z5;
	x[26] = z6;
	x[34] = z7;
	x[32] = z8;
	x[41] = z9;
	x[126] = z10;
	x[19] = z11;
}

void OneRoundConstraints01(GRBModel& model, vector<GRBVar>& x)
{
	GRBVar y1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y10 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y11 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar a = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar b = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar c = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar z1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z8 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z9 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z10 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z11 = model.addVar(0, 1, 0, GRB_BINARY);

	model.addConstr(x[6] <= y1 + z1);
	model.addConstr(y1 <= x[6]);
	model.addConstr(z1 <= x[6]);

	model.addConstr(x[3] <= a + z2);
	model.addConstr(a <= x[3]);
	model.addConstr(z2 <= x[3]);

	model.addConstr(x[11] <= a + z3);
	model.addConstr(a <= x[11]);
	model.addConstr(z3 <= x[11]);

	model.addConstr(x[127] <= y4 + z4);
	model.addConstr(y4 <= x[127]);
	model.addConstr(z4 <= x[127]);

	model.addConstr(x[28] <= y5 + z5);
	model.addConstr(y5 <= x[28]);
	model.addConstr(z5 <= x[28]);

	model.addConstr(x[26] <= b + z6);
	model.addConstr(b <= x[26]);
	model.addConstr(z6 <= x[26]);

	model.addConstr(x[34] <= b + z7);
	model.addConstr(b <= x[34]);
	model.addConstr(z7 <= x[34]);

	model.addConstr(x[32] <= c + z8);
	model.addConstr(c <= x[32]);
	model.addConstr(z8 <= x[32]);

	model.addConstr(x[41] <= c + z9);
	model.addConstr(c <= x[41]);
	model.addConstr(z9 <= x[41]);

	model.addConstr(x[126] <= y10 + z10);
	model.addConstr(y10 <= x[126]);
	model.addConstr(z10 <= x[126]);

	model.addConstr(y11 == x[0] + y1 + a + y4);
	model.addConstr(z11 == x[19] + y5 + b + c + y10);

	x[6] = z1;
	x[3] = z2;
	x[11] = z3;
	x[127] = z4;
	x[0] = y11;

	x[28] = z5;
	x[26] = z6;
	x[34] = z7;
	x[32] = z8;
	x[41] = z9;
	x[126] = z10;
	x[19] = z11;

	vector<GRBVar> temp1 = x;
	OneRoundKeyScheduleConstraint(model, temp1);
	for (int i = 49; i < 128; i++)
	{
		x[i] = temp1[i - 1];
	}
	x[48] = temp1[127];

	//vector<GRBVar> temp2 = x;
	OneRoundKeyScheduleConstraint(model, x);  //temp2
	//for (int i = 33; i < 112; i++)
	//{
		//x[i] = temp2[i - 1];
	//}
	//x[32] = temp2[111];
}

//IR=1
void OneRoundConstraints10(GRBModel& model, vector<GRBVar>& x)
{
	GRBVar y1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y10 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y11 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y12 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar a = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar b = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar c = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar z1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z8 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z9 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z10 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z11 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z12 = model.addVar(0, 1, 0, GRB_BINARY);

	model.addConstr(x[6] <= y1 + z1);
	model.addConstr(y1 <= x[6]);
	model.addConstr(z1 <= x[6]);

	model.addConstr(x[3] <= a + z2);
	model.addConstr(a <= x[3]);
	model.addConstr(z2 <= x[3]);

	model.addConstr(x[11] <= a + z3);
	model.addConstr(a <= x[11]);
	model.addConstr(z3 <= x[11]);

	model.addConstr(x[127] <= y4 + z4);
	model.addConstr(y4 <= x[127]);
	model.addConstr(z4 <= x[127]);

	model.addConstr(x[28] <= y5 + z5);
	model.addConstr(y5 <= x[28]);
	model.addConstr(z5 <= x[28]);

	model.addConstr(x[26] <= b + z6);
	model.addConstr(b <= x[26]);
	model.addConstr(z6 <= x[26]);

	model.addConstr(x[34] <= b + z7);
	model.addConstr(b <= x[34]);
	model.addConstr(z7 <= x[34]);

	model.addConstr(x[32] <= c + z8);
	model.addConstr(c <= x[32]);
	model.addConstr(z8 <= x[32]);

	model.addConstr(x[41] <= c + z9);
	model.addConstr(c <= x[41]);
	model.addConstr(z9 <= x[41]);

	model.addConstr(x[126] <= y10 + z10);
	model.addConstr(y10 <= x[126]);
	model.addConstr(z10 <= x[126]);

	model.addConstr(x[12] <= y11 + z11);
	model.addConstr(y11 <= x[12]);
	model.addConstr(z11 <= x[12]);

	model.addConstr(y12 == x[0] + y1 + a + y4 + y11);
	model.addConstr(z12 == x[19] + y5 + b + c + y10);

	x[6] = z1;
	x[3] = z2;
	x[11] = z3;
	x[12] = z11;
	x[127] = z4;
	x[0] = y12;

	x[28] = z5;
	x[26] = z6;
	x[34] = z7;
	x[32] = z8;
	x[41] = z9;
	x[126] = z10;
	x[19] = z12;
}

void OneRoundConstraints11(GRBModel& model, vector<GRBVar>& x)
{
	GRBVar y1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y10 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y11 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar y12 = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar a = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar b = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar c = model.addVar(0, 1, 0, GRB_BINARY);

	GRBVar z1 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z2 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z3 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z4 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z5 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z6 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z7 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z8 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z9 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z10 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z11 = model.addVar(0, 1, 0, GRB_BINARY);
	GRBVar z12 = model.addVar(0, 1, 0, GRB_BINARY);

	model.addConstr(x[6] <= y1 + z1);
	model.addConstr(y1 <= x[6]);
	model.addConstr(z1 <= x[6]);

	model.addConstr(x[3] <= a + z2);
	model.addConstr(a <= x[3]);
	model.addConstr(z2 <= x[3]);

	model.addConstr(x[11] <= a + z3);
	model.addConstr(a <= x[11]);
	model.addConstr(z3 <= x[11]);
	//model.addConstr(a == y2);
	//model.addConstr(a == y3);

	model.addConstr(x[127] <= y4 + z4);
	model.addConstr(y4 <= x[127]);
	model.addConstr(z4 <= x[127]);

	model.addConstr(x[28] <= y5 + z5);
	model.addConstr(y5 <= x[28]);
	model.addConstr(z5 <= x[28]);

	model.addConstr(x[26] <= b + z6);
	model.addConstr(b <= x[26]);
	model.addConstr(z6 <= x[26]);

	model.addConstr(x[34] <= b + z7);
	model.addConstr(b <= x[34]);
	model.addConstr(z7 <= x[34]);
	//model.addConstr(b == y6);
	//model.addConstr(b == y7);

	model.addConstr(x[32] <= c + z8);
	model.addConstr(c <= x[32]);
	model.addConstr(z8 <= x[32]);

	model.addConstr(x[41] <= c + z9);
	model.addConstr(c <= x[41]);
	model.addConstr(z9 <= x[41]);
	//model.addConstr(c == y8);
	//model.addConstr(c == y9);

	model.addConstr(x[126] <= y10 + z10);
	model.addConstr(y10 <= x[126]);
	model.addConstr(z10 <= x[126]);

	model.addConstr(x[12] <= y11 + z11);
	model.addConstr(y11 <= x[12]);
	model.addConstr(z11 <= x[12]);

	model.addConstr(y12 == x[0] + y1 + a + y4 + y11);
	model.addConstr(z12 == x[19] + y5 + b + c + y10);

	x[6] = z1;
	x[3] = z2;
	x[11] = z3;
	x[12] = z11;
	x[127] = z4;
	x[0] = y12;

	x[28] = z5;
	x[26] = z6;
	x[34] = z7;
	x[32] = z8;
	x[41] = z9;
	x[126] = z10;
	x[19] = z12;

	vector<GRBVar> temp1 = x;
	OneRoundKeyScheduleConstraint(model, temp1);
	for (int i = 49; i < 128; i++)
	{
		x[i] = temp1[i - 1];
	}
	x[48] = temp1[127];

	//vector<GRBVar> temp2 = x;
	OneRoundKeyScheduleConstraint(model, x);//temp2
	//for (int i = 33; i < 112; i++)
	//{
		//x[i] = temp2[i - 1];
	//}
	//x[32] = temp2[111];
}

//callback
class MyCallBack : public GRBCallback
{
public:
	vector<vector<GRBVar>> N_S;
	map<bitset<128>, int, cmpBitsetN>* N_CountingBox;
	int N_ThreadNumber;
	ofstream* N_OutputFile;
	int N_d;

	MyCallBack(vector<vector<GRBVar>> s, map<bitset<128>, int, cmpBitsetN>* CountingBox, int ThreadNumber, ofstream* OutputFile, int d) {
		N_S = s;
		N_CountingBox = CountingBox;
		N_ThreadNumber = ThreadNumber;
		N_OutputFile = OutputFile;
		N_d = d;
	};
protected:
	void callback() {
		try {
			if (where == GRB_CB_MIPSOL) {
				int EvalNumRounds = N_S.size() - 1;
				int divRound = EvalNumRounds / 2;
				*N_OutputFile << "divided in " << divRound << "\t" << getDoubleInfo(GRB_CB_RUNTIME) << "sec" << endl;


				//store found solution into trail
				vector<bitset<128>> trail(EvalNumRounds + 1);
				for (int r = 0; r <= EvalNumRounds; r++) {
					for (int i = 0; i < 128; i++) {
						if (round(getSolution(N_S[r][i])) == 1) trail[r][i] = 1;
						else trail[r][i] = 0;
					}
				}
				double duration = 0;
				int solCnt = ModelConstructFunction(EvalNumRounds, *N_CountingBox, duration, N_ThreadNumber, { true, divRound, trail }, N_d);


				int solTotal = 0;
				auto it = (*N_CountingBox).begin();
				while (it != (*N_CountingBox).end()) {
					solTotal += (*it).second;
					it++;
				}

				(*N_OutputFile) << "\t" << solCnt << "( total : " << solTotal << ")" << endl;
				(*N_OutputFile) << "\t" << (*N_CountingBox).size() << " monomials are involved" << endl;

				GRBLinExpr addCon = 0;
				for (int i = 0; i < 128; i++) {
					if (round(getSolution(N_S[divRound][i])) == 1) {
						addCon += (1 - N_S[divRound][i]);
					}
					else {
						addCon += N_S[divRound][i];
					}
				}
				addLazy(addCon >= 1);
			}
			else if (where == GRB_CB_MESSAGE) {
				string msg = getStringInfo(GRB_CB_MSG_STRING);
				*N_OutputFile << msg << flush;
			}

		}
		catch (GRBException e) {
			cerr << "Error number: " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}
		catch (...) {
			cout << "Error during callback" << endl;
		}
	}
};

int ModelConstructFunction(int EvalNumRounds, map<bitset<128>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d) {
	try {
		// Create the environment
		GRBEnv env = GRBEnv();

		// close standard output
		env.set(GRB_IntParam_LogToConsole, 0);
		env.set(GRB_IntParam_Threads, ThreadNumber);
		env.set(GRB_IntParam_MIPFocus, GRB_MIPFOCUS_BESTBOUND);

		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			env.set(GRB_IntParam_LazyConstraints, 1);
			env.set(GRB_DoubleParam_TimeLimit, 200000);//�������ʱ��Ϊ50000��
		}
		else if ((opt.useTwoStage == true) && (opt.hint.size() > 0)) {
			env.set(GRB_IntParam_PoolSearchMode, 2);
			env.set(GRB_IntParam_PoolSolutions, 2000000000);
			env.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);
		}

		// Create the model
		GRBModel model = GRBModel(env);

		// Create variables
		vector<vector<GRBVar>> s(EvalNumRounds + 1, vector<GRBVar>(128));
		for (int i = 0; i < 128; i++) {
			s[0][i] = model.addVar(0, 1, 0, GRB_BINARY);
		}

		//Set the initial division property
		for (int i = 0; i < 48; i++) {
			if (Cube[i] == 1) {
				model.addConstr(s[0][i] == 1);
			}
			else {
				model.addConstr(s[0][i] == 0);
			}
		}

		// Set constraints for updating EvalNumRounds rounds
		for (int r = 0; r < EvalNumRounds; r++)
		{
			// one round constraint
			if (IR[r] == 0)
			{
				vector<GRBVar> temp = s[r];
				OneRoundConstraints00(model, temp);
				for (int i = 0; i < 48; i++)
				{
					s[r][i] = temp[(i + 1) % 48];
				}
				s[r][126] = temp[126];
				s[r][127] = temp[127];

				//vector<GRBVar>
				temp = s[r];
				OneRoundConstraints01(model, temp);
				for (int i = 0; i < 48; i++)
				{
					s[r + 1][i] = temp[(i + 1) % 48];
				}

				for (int i = 49; i < 128; i++)
				{
					s[r + 1][i] = temp[i - 1];
				}
				s[r + 1][48] = temp[127];
			}
			else
			{
				vector<GRBVar> temp = s[r];
				OneRoundConstraints10(model, temp);
				for (int i = 0; i < 48; i++)
				{
					s[r][i] = temp[(i + 1) % 48];
				}
				s[r][126] = temp[126];
				s[r][127] = temp[127];

				temp = s[r];
				OneRoundConstraints11(model, temp);
				for (int i = 0; i < 48; i++)
				{
					s[r + 1][i] = temp[(i + 1) % 48];
				}

				for (int i = 49; i < 128; i++)
				{
					s[r + 1][i] = temp[i - 1];
				}
				s[r + 1][48] = temp[127];
			}
		}

		//Set the end division property 
		for (int i = 0; i < 128; i++) {
			if ((EndDivisionProperty[d][i] == 1))
				model.addConstr(s[EvalNumRounds][i] == 1);
			else
				model.addConstr(s[EvalNumRounds][i] == 0);
		}

		GRBLinExpr sumKey = 0;
		for (int i = 48; i < 128; i++) {
			sumKey += s[0][i];
		}
		model.setObjective(sumKey, GRB_MAXIMIZE);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {

				for (int i = 0; i < 128; i++) {
					if (opt.hint[opt.divRound][i] == 1)
						model.addConstr(s[opt.divRound][i] == 1);
					else
						model.addConstr(s[opt.divRound][i] == 0);
				}

				for (int r = 0; r < EvalNumRounds; r++) {
					for (int i = 0; i < 128; i++) {
						if (opt.hint[r][i] == 1)
							s[r][i].set(GRB_DoubleAttr_Start, 1);
						else
							s[r][i].set(GRB_DoubleAttr_Start, 0);
					}
				}
			}
		}

		ofstream outputfile2;
		outputfile2.open("StartDivisionPropertyInformation(84,0).txt", ios::app);//status == 2

		model.update();
		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			MyCallBack MCB = MyCallBack(s, &countingBox, ThreadNumber, &outputfile2, d);
			model.setCallback(&MCB);
			model.optimize();
		}
		else {
			model.optimize();
		}

		// The number of total solutions and the time to obtain the total solutions
		int SolCount = model.get(GRB_IntAttr_SolCount);
		duration = model.get(GRB_DoubleAttr_Runtime);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {
				// check solution limit
				if (SolCount >= 2000000000) {
					cerr << "Number of solutions is too large" << endl;
					exit(0);
				}

				// store the information about solutions
				for (int i = 0; i < SolCount; i++) {
					model.set(GRB_IntParam_SolutionNumber, i);
					bitset<128> tmp;
					for (int j = 0; j < 128; j++) {
						if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
						else tmp[j] = 0;
					}
					countingBox[tmp]++;
				}

				return SolCount;
			}
		}
		else {
			// check solution limit
			if (SolCount >= 2000000000) {
				cerr << "Number of solutions is too large" << endl;
				exit(0);
			}

			// store the information about solutions
			for (int i = 0; i < SolCount; i++) {
				model.set(GRB_IntParam_SolutionNumber, i);
				bitset<128> tmp;
				for (int j = 0; j < 128; j++) {
					if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
					else tmp[j] = 0;
				}
				countingBox[tmp]++;
			}
		}

		//result
		if (model.get(GRB_IntAttr_Status) == GRB_INFEASIBLE) {
			return -1;
		}
		else if ((model.get(GRB_IntAttr_Status) == GRB_OPTIMAL)) {
			int upperBound = round(model.get(GRB_DoubleAttr_ObjVal));
			return upperBound;
		}
		else {
			cout << model.get(GRB_IntAttr_Status) << endl;
			return -2;
		}


	}
	catch (GRBException e) {
		cerr << "Error code = " << e.getErrorCode() << endl;
		cerr << e.getMessage() << endl;
	}
	catch (...) {
		cerr << "Exception during optimization" << endl;
	}

	return -1;
}


int main()
{
	double duration = 0;
	int ThreadNumber = 8, EvalNumRounds = 0;  
	int StartRounds = 0, EndRounds = 0;
	cout << "the number of Starting rounds:" << endl;
	cin >> StartRounds;
	cout << " the number of Ending rounds:" << endl;
	cin >> EndRounds;
	EvalNumRounds = EndRounds - StartRounds;
	map<bitset<128>, int, cmpBitsetN> countingBox;

	ofstream outputfile1;
	outputfile1.open("Timelimit(84,0).txt", ios::out);//status == 9
	outputfile1.close();

	ofstream outputfile2;
	outputfile2.open("StartDivisionPropertyInformation(84,0).txt", ios::out);//status == 2
	outputfile2.close();

	ofstream outputfile3;
	outputfile3.open("EndDivisionPropertyInformation(84,0).txt", ios::out);
	outputfile3.close();


	for (int d = 0; d < 1; d++) {   
		try {

			//countingBox
			ModelConstructFunction(EvalNumRounds, countingBox, duration, ThreadNumber, { true,0, }, d);


			ofstream outputfile2;
			outputfile2.open("StartDivisionPropertyInformation(84,0).txt", ios::app);  //status == 2
			auto it = countingBox.begin();
			while (it != countingBox.end()) {
				if (((*it).second % 2) == 1) {
					outputfile2 << "Parity of occurrence times��" << (*it).second % 2 << " " << " The actual number of occurrences��" << (*it).second << "\t";
					for (int i = 48; i < 128; i++) {
						if ((*it).first[i] == 1) {
							outputfile2 << "k" << (i - 48); // 
						}
					}
					outputfile2 << endl;
				}
				it++;
			}
			outputfile2 << "Total time��" << duration << "sec";
			outputfile2.close();
		}
		catch (GRBException e) {
			cerr << "Error code = " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}

		catch (...) {
			cerr << "Exception during optimization" << endl;
		}

	}
}
