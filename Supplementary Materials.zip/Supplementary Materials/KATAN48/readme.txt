This folder contains the integral polynomial of KATAN48.
Let's illustrate the meaning of each file's name.
For example, 'StartDivisionPropertyInformation(84R,0)' represents 
the integral polynomial of 84-round KATAN48. We can get the integral polynomial p 
 corresponding to  the initial division property in47 by summing up all the monomials in the file.