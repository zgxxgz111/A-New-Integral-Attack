# include "gurobi_c++.h"
# include <time.h>
# include <bitset>
# include <iostream>  
# include <vector>   
# include <map>    
# include <fstream>   
# include <exception>

using namespace std;
int ThreadNumber = 8, EvalNumRounds = 0;  
int StartRounds = 0, EndRounds = 0;
int EndDivisionProperty[16][192] = 
{
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
//
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
};
                              //
int RoundKeyAddConstant[66] = { 0,0,0,0,0,1,  0,0,0,0,1,1,  0,0,0,1,1,1,  0,0,1,1,1,1,   0,1,1,1,1,1,    1,1,1,1,1,0,  1,1,1,1,0,1,  1,1,1,0,1,1,  1,1,0,1,1,1,  1,0,1,1,1,1,  0,1,1,1,1,0, };
int Inequality[21][9] = { {4, 10, 4, 5, -2, -7, -6, -3, 3},
{-3, -3, -5, -4, 2, 3, 1, 1, 8},
{1, 1, 1, 2, -2, -1, 0, 0, 0},
{-3, -1, -1, -2, 6, 5, 3, 3, 0},
{2, 3, 0, 4, -1, -5, -1, -5, 5},
{1, -1, -1, 0, 0, 1, 1, 1, 0},
{-1, -1, 1, 2, -2, -1, 1, 1, 2},
{1, 0, 0, -1, 1, -1, 0, 1, 1},
{2, 3, 0, 0, -1, -1, -1, -2, 2},
{0, 0, 1, 1, 0, 0, -1, -1, 1},
{-1, 0, -1, 0, -1, -1, 0, 1, 3},
{-2, -3, -2, -3, 1, 1, -1, 2, 7},
{-1, -1, 0, -1, -1, 0, 1, -1, 4},
{0, 1, 1, 0, 0, 0, -1, -1, 1},
{-2, -1, -2, -2, 1, 1, 1, 0, 4},
{1, 0, -1, 1, 0, 1, 0, 1, 0},
{1, 0, 0, 2, -1, -1, 0, -1, 1},
{1, -1, 0, 0, -1, 1, 0, 1, 1},
{-2, -2, -1, -1, 3, 3, 3, 0, 2},
{1, 3, 2, 3, -2, -2, -1, 0, 0},
{-2, 1, 0, -2, 2, 3, 1, 1, 1},
};

struct cmpBitsetN
{
	bool operator()(const bitset<192>& a, const bitset<192>& b) const
	{
		for (int i = 0; i < 192; i++)
		{
			if (a[i] < b[i])
				return true;
			else if (a[i] > b[i])
				return false;
		}
		return false;
	}
};

struct twoStage {
	bool useTwoStage;
	int divRound;
	vector<bitset<192>> hint;  
};

int ModelConstructFunction(int EvalNumRounds, map<bitset<192>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d);

//callback
class MyCallBack : public GRBCallback
{
public:
	vector<vector<GRBVar>> N_S;
	map<bitset<192>, int, cmpBitsetN>* N_CountingBox;
	int N_ThreadNumber;
	ofstream* N_OutputFile;
	int N_d;

	MyCallBack(vector<vector<GRBVar>> s, map<bitset<192>, int, cmpBitsetN>* CountingBox, int ThreadNumber, ofstream* OutputFile, int d) {
		N_S = s;
		N_CountingBox = CountingBox;
		N_ThreadNumber = ThreadNumber;
		N_OutputFile = OutputFile;
		N_d = d;
	};
protected:
	void callback() {
		try {
			if (where == GRB_CB_MIPSOL) {
				int EvalNumRounds = N_S.size() - 1;
				int divRound = EvalNumRounds / 2;
				*N_OutputFile << "divided in " << divRound << "\t" << getDoubleInfo(GRB_CB_RUNTIME) << "sec" << endl;


				//store found solution into trail
				vector<bitset<192>> trail(EvalNumRounds + 1);
				for (int r = 0; r <= EvalNumRounds; r++) {
					for (int i = 0; i < 192; i++) {
						if (round(getSolution(N_S[r][i])) == 1) trail[r][i] = 1;
						else trail[r][i] = 0;
					}
				}
				double duration = 0;
				int solCnt = ModelConstructFunction(EvalNumRounds, *N_CountingBox, duration, N_ThreadNumber, { true, divRound, trail }, N_d);


				int solTotal = 0;
				auto it = (*N_CountingBox).begin();
				while (it != (*N_CountingBox).end()) {
					solTotal += (*it).second;
					it++;
				}

				(*N_OutputFile) << "\t" << solCnt << "( total : " << solTotal << ")" << endl;
				(*N_OutputFile) << "\t" << (*N_CountingBox).size() << " monomials are involved" << endl;

				GRBLinExpr addCon = 0;
				for (int i = 0; i < 192; i++) {
					if (round(getSolution(N_S[divRound][i])) == 1) {
						addCon += (1 - N_S[divRound][i]);
					}
					else {
						addCon += N_S[divRound][i];
					}
				}
				addLazy(addCon >= 1);
			}
			else if (where == GRB_CB_MESSAGE) {
				string msg = getStringInfo(GRB_CB_MSG_STRING);
				*N_OutputFile << msg << flush;
			}

		}
		catch (GRBException e) {
			cerr << "Error number: " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}
		catch (...) {
			cout << "Error during callback" << endl;
		}
	}
};


void OneRoundConstraints(GRBModel& model, vector<GRBVar>& x, int j) {


	vector<GRBVar> temp1(16), temp2(16);
	for (int i = 0; i < 16; i++) {
		temp1[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp2[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	for (int i = 160; i < 176; i++) {
		model.addConstr(x[i] <= temp1[i - 160] + temp2[i - 160]);
		model.addConstr(temp1[i - 160] <= x[i]);
		model.addConstr(temp2[i - 160] <= x[i]);
	}
	vector<GRBVar> temp3(16), temp4(16);
	for (int i = 0; i < 16; i++) {
		temp3[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp4[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	for (int i = 176; i < 192; i++) {
		model.addConstr(x[i] <= temp3[i - 176] + temp4[i - 176]);
		model.addConstr(temp3[i - 176] <= x[i]);
		model.addConstr(temp4[i - 176] <= x[i]);
	}

	vector<GRBVar> temp5(16), temp6(16), temp7(16), temp8(16), temp9(16), temp10(16);
	for (int i = 64; i < 80; i++) {
		temp5[i - 64] = x[i];
	}
	for (int i = 80; i < 96; i++) {
		temp6[i - 80] = x[i];
	}
	for (int i = 96; i < 112; i++) {
		temp7[i - 96] = x[i];
	}
	for (int i = 112; i < 128; i++) {
		temp8[i - 112] = x[i];
	}
	for (int i = 128; i < 144; i++) {
		temp9[i - 128] = x[i];
	}
	for (int i = 144; i < 160; i++) {
		temp10[i - 144] = x[i];
	}


	for (int i = 0; i < 16; i++) {
		x[i + 64] = temp2[(i + 14) % 16];
	}
	for (int i = 0; i < 16; i++) {
		x[80 + i] = temp4[(i + 4) % 16];
	}
	for (int i = 0; i < 16; i++) {
		x[96 + i] = temp5[i];
	}
	for (int i = 0; i < 16; i++) {
		x[112 + i] = temp6[i];
	}
	for (int i = 0; i < 16; i++) {
		x[128 + i] = temp7[i];
	}
	for (int i = 0; i < 16; i++) {
		x[144 + i] = temp8[i];
	}
	for (int i = 0; i < 16; i++) {
		x[160 + i] = temp9[i];
	}
	for (int i = 0; i < 16; i++) {
		x[176 + i] = temp10[i];
	}


	vector<GRBVar> temp11(64);
	for (int i = 0; i < 64; i++) {
		temp11[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	for (int k = 0; k < 16; k++) {
		model.addConstr(4 * x[k * 4] + 10 * x[k * 4 + 1] + 4 * x[k * 4 + 2] + 5 * x[k * 4 + 3] - 2 * temp11[k * 4] - 7 * temp11[k * 4 + 1] - 6 * temp11[k * 4 + 2] - 3 * temp11[k * 4 + 3] + 3 >= 0);
		model.addConstr(-3 * x[k * 4] - 3 * x[k * 4 + 1] - 5 * x[k * 4 + 2] - 4 * x[k * 4 + 3] + 2 * temp11[k * 4] + 3 * temp11[k * 4 + 1] + temp11[k * 4 + 2] + temp11[k * 4 + 3] + 8 >= 0);
		model.addConstr(x[k * 4] + x[k * 4 + 1] + x[k * 4 + 2] + 2 * x[k * 4 + 3] - 2 * temp11[k * 4] - temp11[k * 4 + 1] >= 0);
		model.addConstr(-3 * x[k * 4] - x[k * 4 + 1] - x[k * 4 + 2] - 2 * x[k * 4 + 3] + 6 * temp11[k * 4] + 5 * temp11[k * 4 + 1] + 3 * temp11[k * 4 + 2] + 3 * temp11[k * 4 + 3] >= 0);
		model.addConstr(2 * x[k * 4] + 3 * x[k * 4 + 1] + 4 * x[k * 4 + 3] - temp11[k * 4] - 5 * temp11[k * 4 + 1] - temp11[k * 4 + 2] - 5 * temp11[k * 4 + 3] + 5 >= 0);
		model.addConstr(x[k * 4] - x[k * 4 + 1] - x[k * 4 + 2] + temp11[k * 4 + 1] + temp11[k * 4 + 2] + temp11[k * 4 + 3] >= 0);
		model.addConstr(-x[k * 4] - x[k * 4 + 1] + x[k * 4 + 2] + 2 * x[k * 4 + 3] - 2 * temp11[k * 4] - temp11[k * 4 + 1] + temp11[k * 4 + 2] + temp11[k * 4 + 3] + 2 >= 0);
		model.addConstr(x[k * 4] - x[k * 4 + 3] + temp11[k * 4] - temp11[k * 4 + 1] + temp11[k * 4 + 3] + 1 >= 0);
		model.addConstr(2 * x[k * 4] + 3 * x[k * 4 + 1] - temp11[k * 4] - temp11[k * 4 + 1] - temp11[k * 4 + 2] - 2 * temp11[k * 4 + 3] + 2 >= 0);
		model.addConstr(x[k * 4 + 2] + x[k * 4 + 3] - temp11[k * 4 + 2] - temp11[k * 4 + 3] + 1 >= 0);
		model.addConstr(-x[k * 4] - x[k * 4 + 2] - temp11[k * 4] - temp11[k * 4 + 1] + temp11[k * 4 + 3] + 3 >= 0);
		model.addConstr(-2 * x[k * 4] - 3 * x[k * 4 + 1] - 2 * x[k * 4 + 2] - 3 * x[k * 4 + 3] + temp11[k * 4] + temp11[k * 4 + 1] - temp11[k * 4 + 2] + 2 * temp11[k * 4 + 3] + 7 >= 0);
		model.addConstr(-x[k * 4] - x[k * 4 + 1] - x[k * 4 + 3] - temp11[k * 4] + temp11[k * 4 + 2] - temp11[k * 4 + 3] + 4 >= 0);
		model.addConstr(x[k * 4 + 1] + x[k * 4 + 2] - temp11[k * 4 + 2] - temp11[k * 4 + 3] + 1 >= 0);
		model.addConstr(-2 * x[k * 4] - x[k * 4 + 1] - 2 * x[k * 4 + 2] - 2 * x[k * 4 + 3] + temp11[k * 4] + temp11[k * 4 + 1] + temp11[k * 4 + 2] + 4 >= 0);
		model.addConstr(x[k * 4] - x[k * 4 + 2] + x[k * 4 + 3] + temp11[k * 4 + 1] + temp11[k * 4 + 3] >= 0);
		model.addConstr(x[k * 4] + 2 * x[k * 4 + 3] - temp11[k * 4] - temp11[k * 4 + 1] - temp11[k * 4 + 3] + 1 >= 0);
		model.addConstr(x[k * 4] - x[k * 4 + 1] - temp11[k * 4] + temp11[k * 4 + 1] + temp11[k * 4 + 3] + 1 >= 0);
		model.addConstr(-2 * x[k * 4] - 2 * x[k * 4 + 1] - x[k * 4 + 2] - x[k * 4 + 3] + 3 * temp11[k * 4] + 3 * temp11[k * 4 + 1] + 3 * temp11[k * 4 + 2] + 2 >= 0);
		model.addConstr(x[k * 4] + 3 * x[k * 4 + 1] + 2 * x[k * 4 + 2] + 3 * x[k * 4 + 3] - 2 * temp11[k * 4] - 2 * temp11[k * 4 + 1] - temp11[k * 4 + 2] >= 0);
		model.addConstr(-2 * x[k * 4] + x[k * 4 + 1] - 2 * x[k * 4 + 3] + 2 * temp11[k * 4] + 3 * temp11[k * 4 + 1] + temp11[k * 4 + 2] + temp11[k * 4 + 3] + 1 >= 0);
	}


	vector<GRBVar> temp12(64);
	temp12[63] = temp11[63]; temp12[63 - 17] = temp11[62]; temp12[63 - 34] = temp11[61]; temp12[63 - 51] = temp11[60]; temp12[63 - 48] = temp11[59]; temp12[63 - 1] = temp11[58]; temp12[63 - 18] = temp11[57]; temp12[63 - 35] = temp11[56];
	temp12[63 - 32] = temp11[55]; temp12[63 - 49] = temp11[54]; temp12[63 - 2] = temp11[53]; temp12[63 - 19] = temp11[52]; temp12[63 - 16] = temp11[51]; temp12[63 - 33] = temp11[50]; temp12[63 - 50] = temp11[49]; temp12[63 - 3] = temp11[48];
	temp12[63 - 4] = temp11[47]; temp12[63 - 21] = temp11[46]; temp12[63 - 38] = temp11[45]; temp12[63 - 55] = temp11[44]; temp12[63 - 52] = temp11[43]; temp12[63 - 5] = temp11[42]; temp12[63 - 22] = temp11[41]; temp12[63 - 39] = temp11[40];
	temp12[63 - 36] = temp11[39]; temp12[63 - 53] = temp11[38]; temp12[63 - 6] = temp11[37]; temp12[63 - 23] = temp11[36]; temp12[63 - 20] = temp11[35]; temp12[63 - 37] = temp11[34]; temp12[63 - 54] = temp11[33]; temp12[63 - 7] = temp11[32];
	temp12[63 - 8] = temp11[31]; temp12[63 - 25] = temp11[30]; temp12[63 - 42] = temp11[29]; temp12[63 - 59] = temp11[28]; temp12[63 - 56] = temp11[27]; temp12[63 - 9] = temp11[26]; temp12[63 - 26] = temp11[25]; temp12[63 - 43] = temp11[24];
	temp12[63 - 40] = temp11[23]; temp12[63 - 57] = temp11[22]; temp12[63 - 10] = temp11[21]; temp12[63 - 27] = temp11[20]; temp12[63 - 24] = temp11[19]; temp12[63 - 41] = temp11[18]; temp12[63 - 58] = temp11[17]; temp12[63 - 11] = temp11[16];
	temp12[63 - 12] = temp11[15]; temp12[63 - 29] = temp11[14]; temp12[63 - 46] = temp11[13]; temp12[63 - 63] = temp11[12]; temp12[63 - 60] = temp11[11]; temp12[63 - 13] = temp11[10]; temp12[63 - 30] = temp11[9]; temp12[63 - 47] = temp11[8];
	temp12[63 - 44] = temp11[7]; temp12[63 - 61] = temp11[6]; temp12[63 - 14] = temp11[5]; temp12[63 - 31] = temp11[4]; temp12[63 - 28] = temp11[3]; temp12[63 - 45] = temp11[2]; temp12[63 - 62] = temp11[1]; temp12[63 - 15] = temp11[0];

	vector<GRBVar> temp13(64);
	for (int i = 0; i < 16; i++) {
		temp13[63 - 4 * i - 1] = model.addVar(0, 1, 0, GRB_BINARY);
		temp13[63 - 4 * i] = model.addVar(0, 1, 0, GRB_BINARY);
		model.addConstr(temp13[63 - 4 * i - 1] == temp12[63 - 4 * i - 1] + temp1[15 - i]);
		model.addConstr(temp13[63 - 4 * i] == temp12[63 - 4 * i] + temp3[15 - i]);
		temp12[63 - 4 * i - 1] = temp13[63 - 4 * i - 1];
		temp12[63 - 4 * i] = temp13[63 - 4 * i];
	}

	vector<GRBVar> temp14(7);
	temp14[0] = model.addVar(0, 1, 0, GRB_BINARY);
	model.addConstr(temp12[0] <= temp14[0]);
	temp12[0] = temp14[0];
	for (int i = 0; i < 6; i++) {
		if (RoundKeyAddConstant[j * 6 + i] == 1) {
			temp14[i + 1] = model.addVar(0, 1, 0, GRB_BINARY);
			model.addConstr(temp12[63 - 23 + 4 * i] <= temp14[i + 1]);
			temp12[63 - 23 + 4 * i] = temp14[i + 1];
		}
	}
	for (int i = 0; i < 64; i++) {
		x[i] = temp12[i];
	}

}

int ModelConstructFunction(int EvalNumRounds, map<bitset<192>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d) {
	try {
		// Create the environment
		GRBEnv env = GRBEnv();

		// close standard output
		env.set(GRB_IntParam_LogToConsole, 0);
		env.set(GRB_IntParam_Threads, ThreadNumber);
		env.set(GRB_IntParam_MIPFocus, GRB_MIPFOCUS_BESTBOUND);

		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			env.set(GRB_IntParam_LazyConstraints, 1);
			env.set(GRB_DoubleParam_TimeLimit, 5000000);
		}
		else if ((opt.useTwoStage == true) && (opt.hint.size() > 0)) {
			env.set(GRB_IntParam_PoolSearchMode, 2);
			env.set(GRB_IntParam_PoolSolutions, 2000000000);
			env.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);
		}

		// Create the model
		GRBModel model = GRBModel(env);

		// Create variables
		vector<vector<GRBVar>> s(EvalNumRounds + 1, vector<GRBVar>(192));
		for (int i = 0; i < 192; i++) {
			s[0][i] = model.addVar(0, 1, 0, GRB_BINARY);
		}


		for (int i = 0; i < 64; i++) {
			if ((i == 0)) {    //   || (i == 63)|| (i == 62)
				model.addConstr(s[0][i] == 0);
			}
			else {
				model.addConstr(s[0][i] == 1);
			}
		}


		for (int r = 0; r < EvalNumRounds; r++) {
			vector<GRBVar> temp = s[r];
			OneRoundConstraints(model, temp, r); 
			for (int i = 0; i < 192; i++) {
				s[r + 1][i] = temp[i];
			}
		}


		for (int i = 0; i < 192; i++) {
			if ((EndDivisionProperty[d][i] == 1))
				model.addConstr(s[EvalNumRounds][i] == 1);
			else
				model.addConstr(s[EvalNumRounds][i] == 0);
		}


		GRBLinExpr sumKey = 0;
		for (int i = 64; i < 192; i++) {
			sumKey += s[0][i];
		}
		model.setObjective(sumKey, GRB_MAXIMIZE);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {

				for (int i = 0; i < 192; i++) {
					if (opt.hint[opt.divRound][i] == 1)
						model.addConstr(s[opt.divRound][i] == 1);
					else
						model.addConstr(s[opt.divRound][i] == 0);
				}

				for (int r = 0; r < EvalNumRounds; r++) {
					for (int i = 0; i < 192; i++) {
						if (opt.hint[r][i] == 1)
							s[r][i].set(GRB_DoubleAttr_Start, 1);
						else
							s[r][i].set(GRB_DoubleAttr_Start, 0);
					}
				}
			}
		}

		ofstream outputfile2;
		outputfile2.open("StartDivisionPropertyInformation(8,0).txt", ios::app);//status == 2

		model.update();
		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			MyCallBack MCB = MyCallBack(s, &countingBox, ThreadNumber, &outputfile2, d);
			model.setCallback(&MCB);
			model.optimize();
		}
		else {
			model.optimize();
		}


		int SolCount = model.get(GRB_IntAttr_SolCount);
		duration = model.get(GRB_DoubleAttr_Runtime);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {
				// check solution limit
				if (SolCount >= 2000000000) {
					cerr << "Number of solutions is too large" << endl;
					exit(0);
				}

				// store the information about solutions
				for (int i = 0; i < SolCount; i++) {
					model.set(GRB_IntParam_SolutionNumber, i);
					bitset<192> tmp;
					for (int j = 0; j < 192; j++) {
						if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
						else tmp[j] = 0;
					}
					countingBox[tmp]++;
				}

				return SolCount;
			}
		}
		else {
			// check solution limit
			if (SolCount >= 2000000000) {
				cerr << "Number of solutions is too large" << endl;
				exit(0);
			}

			// store the information about solutions
			for (int i = 0; i < SolCount; i++) {
				model.set(GRB_IntParam_SolutionNumber, i);
				bitset<192> tmp;
				for (int j = 0; j < 192; j++) {
					if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
					else tmp[j] = 0;
				}
				countingBox[tmp]++;
			}
		}

		//result
		if (model.get(GRB_IntAttr_Status) == GRB_INFEASIBLE) {
			return -1;
		}
		else if ((model.get(GRB_IntAttr_Status) == GRB_OPTIMAL)) {
			int upperBound = round(model.get(GRB_DoubleAttr_ObjVal));
			return upperBound;
		}
		else {
			cout << model.get(GRB_IntAttr_Status) << endl;
			return -2;
		}


	}
	catch (GRBException e) {
		cerr << "Error code = " << e.getErrorCode() << endl;
		cerr << e.getMessage() << endl;
	}
	catch (...) {
		cerr << "Exception during optimization" << endl;
	}

	return -1;
}


int main()
{
	double duration = 0;
	int ThreadNumber = 8, EvalNumRounds = 0;  
	int StartRounds = 0, EndRounds = 0;
	cout << "the number of Starting rounds:" << endl;
	cin >> StartRounds;
	cout << "the number of Ending rounds:" << endl;
	cin >> EndRounds;
	EvalNumRounds = EndRounds - StartRounds;
	map<bitset<192>, int, cmpBitsetN> countingBox;

	ofstream outputfile1;
	outputfile1.open("Timelimit(8,0).txt", ios::out);//status == 9
	outputfile1.close();

	ofstream outputfile2;
	outputfile2.open("StartDivisionPropertyInformation(8,0).txt", ios::out);//status == 2
	outputfile2.close();

	ofstream outputfile3;
	outputfile3.open("EndDivisionPropertyInformation(8,0).txt", ios::out);
	outputfile3.close();

	for (int d = 0; d < 1; d++) {   // 63639
		try {

			ModelConstructFunction(EvalNumRounds, countingBox, duration, ThreadNumber, { true,0, }, d);


			ofstream outputfile2;
			outputfile2.open("StartDivisionPropertyInformation(8,0).txt", ios::app);  //status == 2
			auto it = countingBox.begin();
			while (it != countingBox.end()) {
				if (((*it).second % 2) == 1) {
					outputfile2 << "Parity of occurrence times��" << (*it).second % 2 << " " << "The actual number of occurrences��" << (*it).second << "\t";
					for (int i = 64; i < 192; i++) {
						if ((*it).first[i] == 1) {
							outputfile2 << "k" << (i - 64); 
						}
					}
					outputfile2 << endl;
				}
				it++;
			}
			outputfile2 << "total time:" << duration << "sec";
			outputfile2.close();
		}
		catch (GRBException e) {
			cerr << "Error code = " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}

		catch (...) {
			cerr << "Exception during optimization" << endl;
		}

	}
}
