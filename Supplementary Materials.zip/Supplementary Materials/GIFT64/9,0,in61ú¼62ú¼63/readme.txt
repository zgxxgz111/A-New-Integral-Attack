This folder contains the integral polynomials of GIFT64.
Let's illustrate the meaning of each file's name.
For example, '9,0,in61,62,63_out3' represents 
the integral polynomial when we set  61-/62-/63-th bits of the initial division property to 0 
and 3-rd bit of the end division property to 1. if the model is infeasible, the bit is balanced.