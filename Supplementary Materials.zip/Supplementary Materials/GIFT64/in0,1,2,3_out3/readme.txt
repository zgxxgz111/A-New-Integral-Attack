This folder contains the integral polynomial of GIFT64.
We can get the integral polynomial p 
corresponding to  the initial division property in0,1,2,3 and the end divison property out3
by summing up all the monomials in all files, where in0,1,2,3 represents that 0-/1-/2-/3-th bits are 0 
and the other bits are 1 ,and out3 represents that 3-th bit is 1 and the other bits are 0.
Let's illustrate the meaning of each file's name.
For example, 'StartDivisionPropertyInformation(i,0,k-th)' represents 
the integral polynomial of  k-th vector of i-th round GIFT64. 