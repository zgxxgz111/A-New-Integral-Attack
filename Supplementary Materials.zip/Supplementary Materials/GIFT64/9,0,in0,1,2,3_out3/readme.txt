This folder contains the integral polynomials of GIFT64 when we set  0-/1-/2-/3-th bits of the initial division property to 0 
and 3-rd bit of the end division property to 1. We can obtain the integral polynomial using a divide-and-conquer approach. 
You can get the integral polynomial by adding monomials in all the files in this folder.