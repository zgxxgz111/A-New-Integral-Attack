This folder contains the integral polynomial of SIMECK32.
Let's illustrate the meaning of each file's name.
For example, 'StartDivisionPropertyInformation(14,0,in0,out18)' represents 
the integral polynomial of 14-round SIMECK32 when we set the initial division property to the in0 and 
the end division property to the out18. We can get the integral polynomial p 
by summing up all the monomials in the file.
When solution count is 0, we get a traditional balance bit.