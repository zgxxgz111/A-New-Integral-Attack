# include "gurobi_c++.h"
# include <time.h>
# include <bitset>
# include <iostream>  
# include <vector>   
# include <map>    
# include <fstream>  
# include <exception>

using namespace std;
int RoundKeyAddConstant[224] = {
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0
};


int EndDivisionProperty[1][96] = 
{ 
{0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
};

int Cube[32] = { 0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,}; 

struct cmpBitsetN   
{                   
	bool operator()(const bitset<96>& a, const bitset<96>& b) const  
	{
		for (int i = 0; i < 96; i++)
		{
			if (a[i] < b[i])
				return true;
			else if (a[i] > b[i])
				return false;
		}
		return false;
	}
};

struct twoStage {
	bool useTwoStage;
	int divRound;
	vector<bitset<96>> hint;   
};

int ModelConstructFunction(int EvalNumRounds, map<bitset<96>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d);

//callback
class MyCallBack : public GRBCallback
{
public:
	vector<vector<GRBVar>> N_S;
	map<bitset<96>, int, cmpBitsetN>* N_CountingBox;
	int N_ThreadNumber;
	ofstream* N_OutputFile;
	int N_d;

	MyCallBack(vector<vector<GRBVar>> s, map<bitset<96>, int, cmpBitsetN>* CountingBox, int ThreadNumber, ofstream* OutputFile, int d) {
		N_S = s;
		N_CountingBox = CountingBox;
		N_ThreadNumber = ThreadNumber;
		N_OutputFile = OutputFile;
		N_d = d;
	};
protected:
	void callback() {
		try {
			if (where == GRB_CB_MIPSOL) {
				int EvalNumRounds = N_S.size() - 1;
				int divRound = EvalNumRounds / 2;
				*N_OutputFile << "divided in " << divRound << "\t" << getDoubleInfo(GRB_CB_RUNTIME) << "sec" << endl;


				//store found solution into trail
				vector<bitset<96>> trail(EvalNumRounds + 1);
				for (int r = 0; r <= EvalNumRounds; r++) {
					for (int i = 0; i < 96; i++) {
						if (round(getSolution(N_S[r][i])) == 1) trail[r][i] = 1;
						else trail[r][i] = 0;
					}
				}
				double duration = 0;
				int solCnt = ModelConstructFunction(EvalNumRounds, *N_CountingBox, duration, N_ThreadNumber, { true, divRound, trail }, N_d);


				int solTotal = 0;
				auto it = (*N_CountingBox).begin();
				while (it != (*N_CountingBox).end()) {
					solTotal += (*it).second;
					it++;
				}

				(*N_OutputFile) << "\t" << solCnt << "( total : " << solTotal << ")" << endl;
				(*N_OutputFile) << "\t" << (*N_CountingBox).size() << " monomials are involved" << endl;

				GRBLinExpr addCon = 0;
				for (int i = 0; i < 96; i++) {
					if (round(getSolution(N_S[divRound][i])) == 1) {
						addCon += (1 - N_S[divRound][i]);
					}
					else {
						addCon += N_S[divRound][i];
					}
				}
				addLazy(addCon >= 1);
			}
			else if (where == GRB_CB_MESSAGE) {
				string msg = getStringInfo(GRB_CB_MSG_STRING);
				*N_OutputFile << msg << flush;
			}

		}
		catch (GRBException e) {
			cerr << "Error number: " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}
		catch (...) {
			cout << "Error during callback" << endl;
		}
	}
};


void OneRoundConstraints(GRBModel& model, vector<GRBVar>& x, int j) {



	vector<GRBVar> temp1(16), temp2(16), temp3(16), temp4(16), temp5(16), temp6(16), temp7(16), temp8(16), temp9(16), temp10(16), temp11(16), temp12(16), temp13(16), temp14(16);
	vector<GRBVar> temp21(96);

	for (int i = 0; i < 16; i++) {
		temp1[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp2[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp21[i + 16] = model.addVar(0, 1, 0, GRB_BINARY);
	}

	for (int i = 0; i < 16; i++) {
		temp3[(i + 0) % 16] = temp1[i];
		temp4[(i + 5) % 16] = temp1[i];
	}


	temp5 = temp2;
	for (int i = 0; i < 16; i++) {
		temp2[(i + 1) % 16] = temp5[i];
	}


	for (int i = 0; i < 16; i++) {
		model.addConstr(x[i] <= temp2[i] + temp3[i] + temp4[i] + temp21[i + 16]);
		model.addConstr(temp2[i] <= x[i]);
		model.addConstr(temp3[i] <= x[i]);
		model.addConstr(temp4[i] <= x[i]);
		model.addConstr(temp21[i + 16] <= x[i]);
	}


	for (int i = 0; i < 16; i++) {
		temp8[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp9[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	for (int i = 0; i < 16; i++) {
		model.addConstr(x[80 + i] <= temp8[i] + temp9[i]);
		model.addConstr(temp8[i] <= x[80 + i]);
		model.addConstr(temp9[i] <= x[80 + i]);
	}

	for (int i = 0; i < 16; i++) {
		temp10[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp11[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp13[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}

	for (int i = 0; i < 16; i++) {
		temp12[(i + 5) % 16] = temp11[i];
	}

	for (int i = 0; i < 16; i++) {
		model.addConstr(x[64 + i] <= temp10[i] + temp11[i] + temp12[i] + temp13[i]);
		model.addConstr(temp10[i] <= x[64 + i]);
		model.addConstr(temp11[i] <= x[64 + i]);
		model.addConstr(temp12[i] <= x[64 + i]);
		model.addConstr(temp13[i] <= x[64 + i]);
	}

	for (int i = 0; i < 16; i++) {
		temp14[i] = temp13[(i + 1) % 16];
	}

	for (int i = 0; i < 16; i++) {
		temp21[i + 32] = model.addVar(0, 1, 0, GRB_BINARY);
	}

	for (int i = 0; i < 16; i++) {
		if (RoundKeyAddConstant[j * 16 + i] == 0)
			model.addConstr(temp21[i + 32] == temp9[i] + temp11[i] + temp14[i]);
		else
			model.addConstr(temp9[i] + temp11[i] + temp14[i] <= temp21[i + 32]);
	}

 
	vector<GRBVar> temp19(16);
	for (int i = 0; i < 16; i++) {
		temp21[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	for (int i = 0; i < 16; i++) {
		model.addConstr(temp21[i] == temp1[i] + temp5[i] + x[16 + i] + temp8[i]);
	}

	for (int i = 48; i < 64; i++) { // ****************** 48 - 63
		temp21[i] = x[i - 16];
	}
	for (int i = 64; i < 80; i++) { // ****************** 64 - 79
		temp21[i] = x[i - 16];
	}
	for (int i = 80; i < 96; i++) { // ****************** 80 - 95
		temp21[i] = temp10[i - 80];
	}

	for (int i = 0; i < 96; i++) { 
		x[i] = temp21[i];
	}
}

int ModelConstructFunction(int EvalNumRounds, map<bitset<96>, int, cmpBitsetN>& countingBox, double& duration, int ThreadNumber, struct twoStage opt, int d) {
	try {
		// Create the environment
		GRBEnv env = GRBEnv();

		// close standard output
		env.set(GRB_IntParam_LogToConsole, 0);
		env.set(GRB_IntParam_Threads, ThreadNumber);
		env.set(GRB_IntParam_MIPFocus, GRB_MIPFOCUS_BESTBOUND);

		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			env.set(GRB_IntParam_LazyConstraints, 1);
			env.set(GRB_DoubleParam_TimeLimit, 500000);//�������ʱ��Ϊ50000��
		}
		else if ((opt.useTwoStage == true) && (opt.hint.size() > 0)) {
			env.set(GRB_IntParam_PoolSearchMode, 2);
			env.set(GRB_IntParam_PoolSolutions, 2000000000);
			env.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);
		}

		// Create the model
		GRBModel model = GRBModel(env);

		// Create variables
		vector<vector<GRBVar>> s(EvalNumRounds + 1, vector<GRBVar>(96));
		for (int i = 0; i < 96; i++) {
			s[0][i] = model.addVar(0, 1, 0, GRB_BINARY);
		}


		for (int i = 0; i < 32; i++) {
			if (Cube[i] == 1) {
				model.addConstr(s[0][i] == 1);
			}
			else {
				model.addConstr(s[0][i] == 0);
			}
		}


		for (int r = 0; r < EvalNumRounds; r++) {
			vector<GRBVar> temp = s[r];
			OneRoundConstraints(model, temp, r); // 
			for (int i = 0; i < 96; i++) {
				s[r + 1][i] = temp[i];
			}
		}


		for (int i = 0; i < 96; i++) {
			if ((EndDivisionProperty[d][i] == 1))
				model.addConstr(s[EvalNumRounds][i] == 1);
			else
				model.addConstr(s[EvalNumRounds][i] == 0);
		}


		GRBLinExpr sumKey = 0;
		for (int i = 32; i < 96; i++) {
			sumKey += s[0][i];
		}
		model.setObjective(sumKey, GRB_MAXIMIZE);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {

				for (int i = 0; i < 96; i++) {
					if (opt.hint[opt.divRound][i] == 1)
						model.addConstr(s[opt.divRound][i] == 1);
					else
						model.addConstr(s[opt.divRound][i] == 0);
				}

				for (int r = 0; r < EvalNumRounds; r++) {
					for (int i = 0; i < 96; i++) {
						if (opt.hint[r][i] == 1)
							s[r][i].set(GRB_DoubleAttr_Start, 1);
						else
							s[r][i].set(GRB_DoubleAttr_Start, 0);
					}
				}
			}
		}

		ofstream outputfile2;
		outputfile2.open("StartDivisionPropertyInformation(11,0).txt", ios::app);//status == 2

		model.update();
		if ((opt.useTwoStage == true) && (opt.hint.size() == 0)) {
			MyCallBack MCB = MyCallBack(s, &countingBox, ThreadNumber, &outputfile2, d);
			model.setCallback(&MCB);
			model.optimize();
		}
		else {
			model.optimize();
		}


		int SolCount = model.get(GRB_IntAttr_SolCount);
		duration = model.get(GRB_DoubleAttr_Runtime);

		if (opt.useTwoStage == true) {
			if (opt.hint.size() > 0) {
				// check solution limit
				if (SolCount >= 2000000000) {
					cerr << "Number of solutions is too large" << endl;
					exit(0);
				}

				// store the information about solutions
				for (int i = 0; i < SolCount; i++) {
					model.set(GRB_IntParam_SolutionNumber, i);
					bitset<96> tmp;
					for (int j = 0; j < 96; j++) {
						if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
						else tmp[j] = 0;
					}
					countingBox[tmp]++;
				}

				return SolCount;
			}
		}
		else {
			// check solution limit
			if (SolCount >= 2000000000) {
				cerr << "Number of solutions is too large" << endl;
				exit(0);
			}

			// store the information about solutions
			for (int i = 0; i < SolCount; i++) {
				model.set(GRB_IntParam_SolutionNumber, i);
				bitset<96> tmp;
				for (int j = 0; j < 96; j++) {
					if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
					else tmp[j] = 0;
				}
				countingBox[tmp]++;
			}
		}

		//result
		if (model.get(GRB_IntAttr_Status) == GRB_INFEASIBLE) {
			return -1;
		}
		else if ((model.get(GRB_IntAttr_Status) == GRB_OPTIMAL)) {
			int upperBound = round(model.get(GRB_DoubleAttr_ObjVal));
			return upperBound;
		}
		else {
			cout << model.get(GRB_IntAttr_Status) << endl;
			return -2;
		}


	}
	catch (GRBException e) {
		cerr << "Error code = " << e.getErrorCode() << endl;
		cerr << e.getMessage() << endl;
	}
	catch (...) {
		cerr << "Exception during optimization" << endl;
	}

	return -1;
}


int main()
{
	double duration = 0;
	int ThreadNumber = 8, EvalNumRounds = 0;  //set the number of rounds and threads
	int StartRounds = 0, EndRounds = 0;
	cout << "the number of strating rounds:" << endl;
	cin >> StartRounds;
	cout << "the number of ending rounds:" << endl;
	cin >> EndRounds;
	EvalNumRounds = EndRounds - StartRounds;
	map<bitset<96>, int, cmpBitsetN> countingBox;

	ofstream outputfile1;
	outputfile1.open("Timelimit(11,0).txt", ios::out);//status == 9
	outputfile1.close();

	ofstream outputfile2;
	outputfile2.open("StartDivisionPropertyInformation(11,0).txt", ios::out);//status == 2
	outputfile2.close();

	ofstream outputfile3;
	outputfile3.open("EndDivisionPropertyInformation(11,0).txt", ios::out);
	outputfile3.close();

	//
	for (int d = 0; d < 1; d++) {   // 63639
		try {

			//countingBox
			ModelConstructFunction(EvalNumRounds, countingBox, duration, ThreadNumber, { true,0, }, d);

			// 
			ofstream outputfile2;
			outputfile2.open("StartDivisionPropertyInformation(11,0).txt", ios::app);  //status == 2
			auto it = countingBox.begin();
			while (it != countingBox.end()) {
				if (((*it).second % 2) == 1) {
					outputfile2 << "Parity of occurrence times��" << (*it).second % 2 << " " << " The actual number of occurrences��" << (*it).second << "\t";
					for (int i = 32; i < 96; i++) {
						if ((*it).first[i] == 1) {
							outputfile2 << "k" << (i - 32); // k0��k1��������k63
						}
					}
					outputfile2 << endl;
				}
				it++;
			}
			outputfile2 << "total time:" << duration << "sec";
			outputfile2.close();
		}
		catch (GRBException e) {
			cerr << "Error code = " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}

		catch (...) {
			cerr << "Exception during optimization" << endl;
		}

	}
}
