#include "gurobi_c++.h"
# include<time.h>
# include<bitset>
# include<iostream>  
# include<vector>   
# include<map>    
# include<fstream>   
# include<exception>

using namespace std;
int ThreadNumber = 8, EvalNumRounds = 0;  
int StartRounds = 0, EndRounds = 0;
//  int N = 96 + 16 * (EndRounds - StartRounds);
int EndDivisionProperty[64][96] = 
{ 
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,},
};


int I[1] = { 0 }; 
int RoundKeyAddConstant[224] = {
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0
};

struct cmpBitsetN   //
{                   //
	bool operator()(const bitset<96>& a, const bitset<96>& b) const  
	{
		for (int i = 0; i < 96; i++)
		{
			if (a[i] < b[i])
				return true;
			else if (a[i] > b[i])
				return false;
		}
		return false;
	}
};

void OneRoundConstraints(GRBModel& model, vector<GRBVar>& x, int j) {



	vector<GRBVar> temp1(16), temp2(16), temp3(16), temp4(16), temp5(16), temp6(16), temp7(16), temp8(16), temp9(16), temp10(16), temp11(16), temp12(16), temp13(16), temp14(16);
	vector<GRBVar> temp21(96);

	for (int i = 0; i < 16; i++) {
		temp1[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp2[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp21[i + 16] = model.addVar(0, 1, 0, GRB_BINARY);
	}

	for (int i = 0; i < 16; i++) {
		temp3[(i + 0) % 16] = temp1[i];
		temp4[(i + 5) % 16] = temp1[i];
	}


	temp5 = temp2;
	for (int i = 0; i < 16; i++) {
		temp2[(i + 1) % 16] = temp5[i];
	}


	for (int i = 0; i < 16; i++) {
		model.addConstr(x[i] <= temp2[i] + temp3[i] + temp4[i] + temp21[i + 16]);
		model.addConstr(temp2[i] <= x[i]);
		model.addConstr(temp3[i] <= x[i]);
		model.addConstr(temp4[i] <= x[i]);
		model.addConstr(temp21[i + 16] <= x[i]);
	}


	for (int i = 0; i < 16; i++) {
		temp8[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp9[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	for (int i = 0; i < 16; i++) {
		model.addConstr(x[80 + i] <= temp8[i] + temp9[i]);
		model.addConstr(temp8[i] <= x[80 + i]);
		model.addConstr(temp9[i] <= x[80 + i]);
	}

	for (int i = 0; i < 16; i++) {
		temp10[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp11[i] = model.addVar(0, 1, 0, GRB_BINARY);
		temp13[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}

	for (int i = 0; i < 16; i++) {
		temp12[(i + 5) % 16] = temp11[i];
	}

	for (int i = 0; i < 16; i++) {
		model.addConstr(x[64 + i] <= temp10[i] + temp11[i] + temp12[i] + temp13[i]);
		model.addConstr(temp10[i] <= x[64 + i]);
		model.addConstr(temp11[i] <= x[64 + i]);
		model.addConstr(temp12[i] <= x[64 + i]);
		model.addConstr(temp13[i] <= x[64 + i]);
	}

	for (int i = 0; i < 16; i++) {
		temp14[i] = temp13[(i + 1) % 16];
	}

	for (int i = 0; i < 16; i++) {
		temp21[i + 32] = model.addVar(0, 1, 0, GRB_BINARY);
	}

	for (int i = 0; i < 16; i++) {
		if (RoundKeyAddConstant[j * 16 + i] == 0)
			model.addConstr(temp21[i + 32] == temp9[i] + temp11[i] + temp14[i]);
		else
			model.addConstr(temp9[i] + temp11[i] + temp14[i] <= temp21[i + 32]);
	}

    
	vector<GRBVar> temp19(16);
	for (int i = 0; i < 16; i++) {
		temp21[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	for (int i = 0; i < 16; i++) {
		model.addConstr(temp21[i] == temp1[i] + temp5[i] + x[16 + i] + temp8[i]);
	}

	for (int i = 48; i < 64; i++) { // ****************** 48 - 63
		temp21[i] = x[i - 16];
	}
	for (int i = 64; i < 80; i++) { // ****************** 64 - 79
		temp21[i] = x[i - 16];
	}
	for (int i = 80; i < 96; i++) { // ****************** 80 - 95
		temp21[i] = temp10[i - 80];
	}

	for (int i = 0; i < 96; i++) { 
		x[i] = temp21[i];
	}
}


int main()
{

	cout << "the number of Starting rounds:" << endl;
	cin >> StartRounds;
	cout << "the number of Ending rounds:" << endl;
	cin >> EndRounds;
	EvalNumRounds = EndRounds - StartRounds;

	ofstream outputfile1;
	outputfile1.open("Timelimit(11,0).txt", ios::out);//status == 9
	outputfile1.close();

	ofstream outputfile2;
	outputfile2.open("StartDivisionPropertyInformation(11,0).txt", ios::out);//status == 2
	outputfile2.close();

	ofstream outputfile3;
	outputfile3.open("EndDivisionPropertyInformation(11,0).txt", ios::out);
	outputfile3.close();


	for (int d = 0; d < 1; d++) { //63639
		try {
			map< bitset<96>, int, cmpBitsetN > countingBox;
			GRBEnv env = GRBEnv();


			env.set(GRB_IntParam_LogToConsole, 0);
			env.set(GRB_IntParam_Threads, ThreadNumber);
			env.set(GRB_IntParam_MIPFocus, GRB_MIPFOCUS_BESTBOUND);

			env.set(GRB_IntParam_PoolSearchMode, 2);
			env.set(GRB_IntParam_PoolSolutions, 2000000000);
			env.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);

			env.set(GRB_DoubleParam_TimeLimit, 10);

			GRBModel model = GRBModel(env);

			vector< vector<GRBVar> > s(EvalNumRounds + 1, vector<GRBVar>(96));

			for (int i = 0; i < 96; i++) {
				s[0][i] = model.addVar(0, 1, 0, GRB_BINARY);
			}


			for (int i = 0; i < 32; i++) {
				if (i == 0)
					model.addConstr(s[0][i] == 0);
				else
					model.addConstr(s[0][i] == 1);
			}

			// EvalNumRounds rounds
			for (int r = 0; r < EvalNumRounds; r++) {
				vector<GRBVar> temp = s[r];
				OneRoundConstraints(model, temp, r + StartRounds); // 
				for (int i = 0; i < 96; i++) {
					s[r + 1][i] = temp[i];
				}
			}

			for (int i = 0; i < 96; i++) {
				if ((EndDivisionProperty[d][i] == 1))        // || (i == 2) || (i == 4) || (i == 10) || (i == 11)
					model.addConstr(s[EvalNumRounds][i] == 1);
				else
					model.addConstr(s[EvalNumRounds][i] == 0);
			}

			model.update();
			model.write("Example.lp");
			model.optimize();

			int status = model.get(GRB_IntAttr_Status);

			if (status == 9) {
				ofstream outputfile1;
				outputfile1.open("Timelimit(11,0).txt", ios::app);
				outputfile1 << d << "-th end division property--cannot solve" << endl;
				outputfile1.close();
			}
			else if (status == 2) {
				int solCount = model.get(GRB_IntAttr_SolCount);
				double dulation = model.get(GRB_DoubleAttr_Runtime);

				if (solCount > 2000000000)
				{
					cerr << "too many solutions" << endl;
					exit(0);
				}

				for (int i = 0; i < solCount; i++) {
					model.set(GRB_IntParam_SolutionNumber, i);
					bitset<96> tmp;
					for (int j = 0; j < 96; j++)
					{
						if (round(s[0][j].get(GRB_DoubleAttr_Xn)) == 1) tmp[j] = 1;
						else tmp[j] = 0;
					}
					countingBox[tmp]++;
				}

				ofstream outputfile;
				outputfile.open("StartDivisionPropertyInformation(11,0).txt", ios::app);
				outputfile << d << " - th end division property--cannot solve" << endl;


				auto it = countingBox.begin();  

				outputfile << "{";
				while (it != countingBox.end())
				{
					bitset<96> tmp = (*it).first;

					outputfile << "{";
					if (((*it).second % 2) == 1) {
						for (int i = 0; i < 96; i++) {
							outputfile << tmp[i] << ",";
						}
					}
					outputfile << "},";
					outputfile << endl;
					it++;
				}
				outputfile << "}";

				outputfile << "\n";
				outputfile << "total time" << dulation << "seconds" << endl;

				outputfile.close();
			}
			else if (status == 3) {
				ofstream outputfile;
				outputfile.open("EndDivisionPropertyInformation(11,0).txt", ios::app);
				outputfile <<  d << " -th  no solution" << endl;
				outputfile.close();
			}

			//delete ( (GRBModel *) &model );
			//delete ( (GRBEnv *) &env );
		}
		catch (GRBException e) {
			cerr << "Error code = " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}

		catch (...) {
			cerr << "Exception during optimization" << endl;
		}

	}


}


