This folder contains codes and the results of the integral polynomials for 5 block ciphers:
KATAN family ciphers, KTANTAN family ciphers, GIFT64, SIMECK32 and SIMON32. 
